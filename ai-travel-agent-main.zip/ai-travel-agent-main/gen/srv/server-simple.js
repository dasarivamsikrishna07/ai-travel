const express = require('express');
const path = require('path');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 3002;

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'app')));

// CORS middleware
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    if (req.method === 'OPTIONS') {
        res.sendStatus(200);
    } else {
        next();
    }
});

// Serve the main app
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'app/index.html'));
});

// Serve webapp resources
app.use('/app/webapp', express.static(path.join(__dirname, 'app/webapp')));

// Health check endpoint
app.get('/service/plan/health', (req, res) => {
    res.json({
        status: 'healthy',
        database: 'connected',
        timestamp: new Date().toISOString()
    });
});

// Service document endpoint
app.get('/service/plan/', (req, res) => {
    res.json({
        "@odata.context": "$metadata",
        "value": [
            {
                "name": "health",
                "kind": "Function",
                "url": "health"
            },
            {
                "name": "generatePlan", 
                "kind": "Function",
                "url": "generatePlan"
            }
        ]
    });
});

// OData metadata endpoint
app.get('/service/plan/$metadata', (req, res) => {
    const metadata = `<?xml version="1.0" encoding="utf-8"?>
<edmx:Edmx Version="4.0" xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx">
  <edmx:DataServices>
    <Schema Namespace="TravelService" xmlns="http://docs.oasis-open.org/odata/ns/edm">
      <EntityContainer Name="EntityContainer">
        <FunctionImport Name="health" Function="TravelService.health"/>
        <FunctionImport Name="generatePlan" Function="TravelService.generatePlan"/>
      </EntityContainer>
      <Function Name="health">
        <ReturnType Type="TravelService.HealthStatus"/>
      </Function>
      <Function Name="generatePlan">
        <Parameter Name="origin" Type="Edm.String"/>
        <Parameter Name="destination" Type="Edm.String"/>
        <Parameter Name="startDate" Type="Edm.String"/>
        <Parameter Name="endDate" Type="Edm.String"/>
        <Parameter Name="budget" Type="Edm.Int32"/>
        <Parameter Name="travelers" Type="Edm.Int32"/>
        <ReturnType Type="TravelService.GeneratedPlan"/>
      </Function>
      <ComplexType Name="HealthStatus">
        <Property Name="status" Type="Edm.String"/>
        <Property Name="database" Type="Edm.String"/>
        <Property Name="timestamp" Type="Edm.String"/>
      </ComplexType>
      <ComplexType Name="GeneratedPlan">
        <Property Name="planJson" Type="Edm.String"/>
      </ComplexType>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>`;
    res.set('Content-Type', 'application/xml');
    res.send(metadata);
});

// Simple travel plan generation endpoint
app.get('/service/plan/generatePlan', async (req, res) => {
    try {
        const { origin, destination, startDate, endDate, budget, travelers } = req.query;
        
        // Simple mock response for now
        const mockPlan = {
            destination: destination || "Goa",
            duration: "3 days",
            totalBudget: budget || 25000,
            dailyItinerary: [
                {
                    day: 1,
                    date: startDate || "2025-08-15",
                    activities: ["Arrival and check-in", "Beach visit", "Local market exploration"],
                    accommodation: "Beach Resort",
                    meals: ["Welcome drink", "Seafood lunch", "Beachside dinner"],
                    dailyCost: 8000
                },
                {
                    day: 2,
                    date: "2025-08-16",
                    activities: ["Water sports", "Spice plantation tour", "Sunset cruise"],
                    accommodation: "Beach Resort",
                    meals: ["Continental breakfast", "Traditional Goan lunch", "Cruise dinner"],
                    dailyCost: 9000
                },
                {
                    day: 3,
                    date: "2025-08-17",
                    activities: ["Old Goa churches", "Shopping", "Departure"],
                    accommodation: "Beach Resort",
                    meals: ["Breakfast", "Farewell lunch"],
                    dailyCost: 8000
                }
            ],
            budgetBreakdown: {
                accommodation: 15000,
                food: 6000,
                transportation: 2000,
                activities: 2000
            },
            tips: ["Carry sunscreen", "Try local cashew feni", "Respect local customs"]
        };

        res.json({ planJson: JSON.stringify(mockPlan) });
    } catch (error) {
        console.error('Error generating plan:', error);
        res.status(500).json({ error: 'Failed to generate travel plan' });
    }
});

// Start server
app.listen(port, () => {
    console.log(`🚀 AI Travel Agent running on http://localhost:${port}`);
    console.log(`📱 Open your browser and visit: http://localhost:${port}`);
});
