const express = require('express');
const path = require('path');
require('dotenv').config();

console.log('🚀 Starting Test AI Travel Agent Server...');

const app = express();
const PORT = 8080;

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'app/webapp')));

// Initialize Gemini AI
let genAI = null;
if (process.env.GEMINI_API_KEY) {
    const { GoogleGenerativeAI } = require('@google/generative-ai');
    genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
    console.log('✅ Gemini AI initialized successfully');
} else {
    console.log('⚠️  GEMINI_API_KEY not found - AI features will be limited');
}

// Health check endpoint
app.get('/service/plan/health', (req, res) => {
    res.json({
        status: 'healthy',
        database: 'not-connected',
        timestamp: new Date().toISOString()
    });
});

// Service document endpoint
app.get('/service/plan/', (req, res) => {
    const serviceDocument = {
        "@odata.context": "$metadata",
        "value": [
            {
                "name": "health",
                "kind": "Function",
                "url": "health"
            },
            {
                "name": "generatePlan",
                "kind": "Function",
                "url": "generatePlan"
            }
        ]
    };
    res.json(serviceDocument);
});

// OData metadata endpoint - Enhanced to prevent 404 errors
app.get('/service/plan/$metadata', (req, res) => {
    const metadata = `<?xml version="1.0" encoding="utf-8"?>
<edmx:Edmx Version="4.0" xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx">
  <edmx:DataServices>
    <Schema Namespace="TravelService" xmlns="http://docs.oasis-open.org/odata/ns/edm">
      <EntityContainer Name="EntityContainer">
        <FunctionImport Name="health" Function="TravelService.health"/>
        <FunctionImport Name="generatePlan" Function="TravelService.generatePlan"/>
        <FunctionImport Name="getTravelPlan" Function="TravelService.getTravelPlan"/>
      </EntityContainer>
      <Function Name="health">
        <ReturnType Type="TravelService.HealthStatus"/>
      </Function>
      <Function Name="generatePlan">
        <Parameter Name="origin" Type="Edm.String"/>
        <Parameter Name="destination" Type="Edm.String"/>
        <Parameter Name="startDate" Type="Edm.String"/>
        <Parameter Name="endDate" Type="Edm.String"/>
        <Parameter Name="budget" Type="Edm.Int32"/>
        <Parameter Name="travelers" Type="Edm.Int32"/>
        <Parameter Name="travelStyle" Type="Edm.String"/>
        <ReturnType Type="TravelService.GeneratedPlan"/>
      </Function>
      <Function Name="getTravelPlan">
        <Parameter Name="planId" Type="Edm.String"/>
        <ReturnType Type="TravelService.GeneratedPlan"/>
      </Function>
      <ComplexType Name="HealthStatus">
        <Property Name="status" Type="Edm.String"/>
        <Property Name="database" Type="Edm.String"/>
        <Property Name="timestamp" Type="Edm.String"/>
      </ComplexType>
      <ComplexType Name="GeneratedPlan">
        <Property Name="planJson" Type="Edm.String"/>
      </ComplexType>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>`;
    res.set('Content-Type', 'application/xml');
    res.set('Cache-Control', 'public, max-age=3600');
    res.send(metadata);
});

// Handle metadata requests with query parameters (like sap-language)
app.get('/service/plan/\\$metadata', (req, res) => {
    res.redirect('/service/plan/$metadata');
});

// Generate travel plan endpoint (GET for OData function calls)
app.get('/service/plan/generatePlan', async (req, res) => {
    console.log('📝 Received plan generation request (GET)');
    try {
        const { origin, destination, startDate, endDate, budget, travelers, travelStyle } = req.query;
        console.log('Parameters:', { origin, destination, startDate, endDate, budget, travelers, travelStyle });

        if (!genAI) {
            return res.status(500).json({ error: 'GEMINI_API_KEY is not configured' });
        }

        // Get weather information if API key is available
        let weatherInfo = "Weather information not available";
        if (process.env.OPENWEATHER_API_KEY) {
            try {
                const weatherResponse = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${destination}&appid=${process.env.OPENWEATHER_API_KEY}&units=metric`);
                if (weatherResponse.ok) {
                    const weatherData = await weatherResponse.json();
                    weatherInfo = `Current: ${weatherData.weather[0].description}, ${Math.round(weatherData.main.temp)}°C, Humidity: ${weatherData.main.humidity}%`;
                }
            } catch (error) {
                console.log('Weather API error:', error.message);
            }
        }

        const numDays = Math.ceil((new Date(endDate) - new Date(startDate)) / (1000*60*60*24));

        const prompt = `
You are Atithi, an expert travel planner for India. Generate a comprehensive travel plan in JSON format with ALL required sections.

Trip Details:
- Origin: ${origin}
- Destination: ${destination}
- Start Date: ${startDate}
- End Date: ${endDate}
- Duration: ${numDays} days
- Budget: ₹${budget}
- Travelers: ${travelers}
- Travel Style: ${travelStyle}
- Current Weather: ${weatherInfo}

IMPORTANT: Generate a complete JSON object with ALL the following sections. Do not omit any section.

{
  "trip_summary": {
    "title": "A ${travelStyle} Trip to ${destination}",
    "destination": "${destination}",
    "duration": "${numDays} Days",
    "total_budget": ${budget},
    "best_time_to_visit": "Detailed note about best season, weather, and travel conditions"
  },
  "itinerary": [
    {
      "day": 1,
      "date": "${startDate}",
      "theme": "Arrival & Exploration",
      "weather": "Expected weather conditions for this day",
      "activities": [
        {
          "time_of_day": "Morning",
          "activity": "Activity name",
          "location": "Specific location name",
          "cost": 500,
          "description": "Detailed activity description",
          "image_search_term": "search term for finding relevant images",
          "tips": "Helpful tips for this activity"
        }
      ]
    }
  ],
  "accommodation_options": {
    "recommended_stays": [
      {
        "name": "Hotel/Resort Name",
        "type": "Hotel/Resort/Guesthouse",
        "location": "Area/Location",
        "price_range": "₹2000-3000 per night",
        "rating": "4.2/5",
        "amenities": ["WiFi", "AC", "Pool"],
        "description": "Detailed description",
        "booking_tips": "How to get best rates"
      }
    ],
    "all_stays": [
      {
        "name": "Budget Option 1",
        "type": "Hostel",
        "location": "Location",
        "price_range": "₹800-1200 per night",
        "rating": "3.8/5",
        "amenities": ["WiFi", "Shared Kitchen"],
        "description": "Budget-friendly option"
      }
    ]
  },
  "food_and_restaurants": {
    "must_try_foods": [
      {
        "dish": "Local dish name",
        "description": "What makes this dish special",
        "where_to_find": "Best places to try this dish",
        "price_range": "₹200-500",
        "image_search_term": "search term for food images"
      }
    ],
    "recommended_restaurants": [
      {
        "name": "Restaurant Name",
        "cuisine": "Type of cuisine",
        "location": "Address/Area",
        "price_range": "₹500-1000 for two",
        "specialties": ["Dish 1", "Dish 2"],
        "rating": "4.3/5",
        "description": "What makes this restaurant special"
      }
    ]
  },
  "transportation": {
    "getting_there": {
      "from_origin": "How to reach ${destination} from ${origin}",
      "options": [
        {
          "mode": "Flight/Train/Bus",
          "duration": "X hours",
          "cost": "₹X-Y",
          "booking_tips": "Best booking platforms and tips"
        }
      ]
    },
    "local_transport": {
      "options": [
        {
          "mode": "Auto/Taxi/Bus",
          "cost": "₹X per km or ₹X per day",
          "description": "When to use and tips"
        }
      ]
    }
  },
  "must_visit_places": [
    {
      "name": "Attraction Name",
      "type": "Temple/Beach/Fort/Museum",
      "location": "Specific location",
      "entry_fee": "₹50 or Free",
      "best_time": "Morning/Evening",
      "duration": "2-3 hours",
      "description": "Detailed description of the place",
      "image_search_term": "search term for images",
      "tips": "Visitor tips and recommendations"
    }
  ],
  "travel_tips": [
    {
      "category": "Weather",
      "tip": "Specific weather-related advice"
    },
    {
      "category": "Safety",
      "tip": "Safety recommendations"
    },
    {
      "category": "Culture",
      "tip": "Cultural etiquette and customs"
    },
    {
      "category": "Money",
      "tip": "Currency and payment advice"
    },
    {
      "category": "Packing",
      "tip": "What to pack for this destination"
    }
  ],
  "budget_breakdown": {
    "accommodation_total": ${Math.floor(budget * 0.4)},
    "transportation_total": ${Math.floor(budget * 0.2)},
    "meals_total": ${Math.floor(budget * 0.25)},
    "activities_total": ${Math.floor(budget * 0.15)}
  }
}

Generate comprehensive, accurate, and detailed information for ${destination}. Include specific local knowledge, current prices, and practical tips.`;

        console.log('🤖 Calling Gemini API with gemini-2.5-pro...');
        const model = genAI.getGenerativeModel({ model: "gemini-2.5-pro" });
        const result = await model.generateContent(prompt);
        const response = result.response;
        const text = response.text();
        console.log('✅ Gemini API response received');

        // Try to parse JSON from the response
        let planJson;
        try {
            const jsonMatch = text.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
                planJson = JSON.parse(jsonMatch[0]);
            } else {
                throw new Error('No JSON found in response');
            }
        } catch (parseError) {
            console.log('⚠️ JSON parsing failed, creating fallback plan');
            // If parsing fails, create a basic structure
            planJson = {
                trip_summary: {
                    title: `${numDays}-Day Trip to ${destination}`,
                    destination: destination,
                    duration: `${numDays} Days`,
                    total_budget: budget,
                    best_time_to_visit: "Year-round destination"
                },
                itinerary: [
                    {
                        day: 1,
                        date: startDate,
                        theme: "Arrival & Exploration",
                        activities: [
                            {
                                time_of_day: "Morning",
                                activity: "Arrival and check-in",
                                location: destination,
                                cost: 0,
                                description: "Arrive at destination and check into accommodation"
                            }
                        ]
                    }
                ],
                budget_breakdown: {
                    accommodation_total: Math.floor(budget * 0.4),
                    transportation_total: Math.floor(budget * 0.2),
                    meals_total: Math.floor(budget * 0.25),
                    activities_total: Math.floor(budget * 0.15)
                }
            };
        }

        res.json({ planJson: JSON.stringify(planJson) });
    } catch (error) {
        console.error('Error generating plan:', error);
        res.status(500).json({ error: 'Failed to generate travel plan: ' + error.message });
    }
});

// POST endpoint for form submissions
app.post('/service/plan/generatePlan', async (req, res) => {
    console.log('📝 Received plan generation request (POST)');
    // Redirect to GET endpoint with query parameters
    const { origin, destination, startDate, endDate, budget, travelers, travelStyle } = req.body;
    const queryParams = new URLSearchParams({
        origin, destination, startDate, endDate, budget, travelers, travelStyle
    });
    
    // Call the GET endpoint internally
    req.query = { origin, destination, startDate, endDate, budget, travelers, travelStyle };
    return app._router.handle(req, res);
});

// Serve the UI5 app
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'app/webapp/index.html'));
});

// Serve static files
app.use('/webapp', express.static(path.join(__dirname, 'app/webapp')));

app.listen(PORT, () => {
    console.log(`🌏 Test AI Travel Agent is running!`);
    console.log(`📱 UI: http://localhost:${PORT}/webapp/`);
    console.log(`🔗 API: http://localhost:${PORT}/service/plan/`);
    console.log(`💡 Health Check: http://localhost:${PORT}/service/plan/health`);
});
