const express = require('express');
const path = require('path');
require('dotenv').config();

console.log('🚀 Starting Bharat-AI Travel Agent...');

const app = express();
const PORT = process.env.PORT || 4004;

console.log('📦 Setting up middleware...');

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'app/webapp')));

console.log('🔑 Initializing Gemini AI...');
// Initialize Gemini AI only if API key is available
let genAI = null;
if (process.env.GEMINI_API_KEY) {
    const { GoogleGenerativeAI } = require('@google/generative-ai');
    genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
    console.log('✅ Gemini AI initialized successfully');
} else {
    console.log('⚠️  GEMINI_API_KEY not found - AI features will be limited');
}



// Generate travel plan endpoint
app.post('/service/plan/generatePlan', async (req, res) => {
    console.log('📝 Received plan generation request');
    try {
        const { origin, destination, startDate, endDate, budget, travelers } = req.body;

        if (!genAI) {
            return res.status(500).json({ error: 'GEMINI_API_KEY is not configured' });
        }

        const numDays = (new Date(endDate) - new Date(startDate)) / (1000*60*60*24) + 1;

        const prompt = `
You are Atithi, an expert travel planner for India. Generate a detailed travel itinerary in JSON format.

Trip Details:
- Origin: ${origin}
- Destination: ${destination}
- Start Date: ${startDate}
- End Date: ${endDate}
- Duration: ${numDays} days
- Budget: ₹${budget}
- Travelers: ${travelers}

Return a JSON object with this structure:
{
  "destination": "${destination}",
  "duration": "${numDays} days",
  "totalBudget": ${budget},
  "dailyItinerary": [
    {
      "day": 1,
      "date": "${startDate}",
      "activities": ["Activity 1", "Activity 2"],
      "accommodation": "Hotel name",
      "meals": ["Breakfast", "Lunch", "Dinner"],
      "dailyCost": 2000
    }
  ],
  "budgetBreakdown": {
    "accommodation": 15000,
    "food": 8000,
    "transportation": 5000,
    "activities": 7000,
    "miscellaneous": 3000
  },
  "tips": ["Tip 1", "Tip 2", "Tip 3"]
}`;

        const model = genAI.getGenerativeModel({ model: "gemini-pro" });
        const result = await model.generateContent(prompt);
        const response = await result.response;
        const text = response.text();

        // Try to parse JSON from the response
        let planJson;
        try {
            const jsonMatch = text.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
                planJson = JSON.parse(jsonMatch[0]);
            } else {
                throw new Error('No JSON found in response');
            }
        } catch (parseError) {
            // If parsing fails, create a basic structure
            planJson = {
                destination: destination,
                duration: `${numDays} days`,
                totalBudget: budget,
                dailyItinerary: [],
                budgetBreakdown: {
                    accommodation: Math.floor(budget * 0.4),
                    food: Math.floor(budget * 0.25),
                    transportation: Math.floor(budget * 0.15),
                    activities: Math.floor(budget * 0.15),
                    miscellaneous: Math.floor(budget * 0.05)
                },
                tips: ["Plan ahead for better deals", "Try local cuisine", "Respect local customs"]
            };
        }

        res.json({ planJson: JSON.stringify(planJson) });
    } catch (error) {
        console.error('Error generating plan:', error);
        res.status(500).json({ error: 'Failed to generate travel plan' });
    }
});

// Add OData metadata endpoint
app.get('/service/plan/$metadata', (req, res) => {
    const metadata = `<?xml version="1.0" encoding="utf-8"?>
<edmx:Edmx Version="4.0" xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx">
  <edmx:DataServices>
    <Schema Namespace="TravelService" xmlns="http://docs.oasis-open.org/odata/ns/edm">
      <EntityContainer Name="EntityContainer">
        <FunctionImport Name="health" Function="TravelService.health"/>
        <FunctionImport Name="generatePlan" Function="TravelService.generatePlan"/>
      </EntityContainer>
      <Function Name="health">
        <ReturnType Type="TravelService.HealthStatus"/>
      </Function>
      <Function Name="generatePlan">
        <Parameter Name="origin" Type="Edm.String"/>
        <Parameter Name="destination" Type="Edm.String"/>
        <Parameter Name="startDate" Type="Edm.String"/>
        <Parameter Name="endDate" Type="Edm.String"/>
        <Parameter Name="budget" Type="Edm.Int32"/>
        <Parameter Name="travelers" Type="Edm.Int32"/>
        <ReturnType Type="TravelService.GeneratedPlan"/>
      </Function>
      <ComplexType Name="HealthStatus">
        <Property Name="status" Type="Edm.String"/>
        <Property Name="database" Type="Edm.String"/>
        <Property Name="timestamp" Type="Edm.String"/>
      </ComplexType>
      <ComplexType Name="GeneratedPlan">
        <Property Name="planJson" Type="Edm.String"/>
      </ComplexType>
    </Schema>
  </edmx:DataServices>
</edmx:Edmx>`;
    res.set('Content-Type', 'application/xml');
    res.send(metadata);
});

// Add service document endpoint
app.get('/service/plan/', (req, res) => {
    const serviceDocument = {
        "@odata.context": "$metadata",
        "value": [
            {
                "name": "health",
                "kind": "Function",
                "url": "health"
            },
            {
                "name": "generatePlan",
                "kind": "Function",
                "url": "generatePlan"
            }
        ]
    };
    res.json(serviceDocument);
});

// Add CDS service endpoints manually
app.get('/service/plan/health', async (req, res) => {
    try {
        res.json({
            status: 'healthy',
            database: 'connected',
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({
            status: 'error',
            database: 'disconnected',
            timestamp: new Date().toISOString(),
            error: error.message
        });
    }
});

// Add the generatePlan endpoint for OData-style calls
app.get('/service/plan/generatePlan', async (req, res) => {
    try {
        const { origin, destination, startDate, endDate, budget, travelers } = req.query;

        if (!genAI) {
            return res.status(500).json({ error: 'GEMINI_API_KEY is not configured' });
        }

        const numDays = (new Date(endDate) - new Date(startDate)) / (1000*60*60*24) + 1;

        const prompt = `
You are Atithi, an expert travel planner for India. Generate a detailed travel itinerary in JSON format.

Trip Details:
- Origin: ${origin}
- Destination: ${destination}
- Start Date: ${startDate}
- End Date: ${endDate}
- Duration: ${numDays} days
- Budget: ₹${budget}
- Travelers: ${travelers}

Return a JSON object with this structure:
{
  "destination": "${destination}",
  "duration": "${numDays} days",
  "totalBudget": ${budget},
  "dailyItinerary": [
    {
      "day": 1,
      "date": "${startDate}",
      "activities": ["Activity 1", "Activity 2"],
      "accommodation": "Hotel name",
      "meals": ["Breakfast", "Lunch", "Dinner"],
      "dailyCost": 2000
    }
  ],
  "budgetBreakdown": {
    "accommodation": 15000,
    "food": 8000,
    "transportation": 5000,
    "activities": 7000,
    "miscellaneous": 3000
  },
  "tips": ["Tip 1", "Tip 2", "Tip 3"]
}`;

        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
        const result = await model.generateContent(prompt);
        const response = await result.response;
        const text = response.text();

        // Try to parse JSON from the response
        let planJson;
        try {
            const jsonMatch = text.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
                planJson = JSON.parse(jsonMatch[0]);
            } else {
                throw new Error('No JSON found in response');
            }
        } catch (parseError) {
            // If parsing fails, create a basic structure
            planJson = {
                destination: destination,
                duration: `${numDays} days`,
                totalBudget: budget,
                dailyItinerary: [],
                budgetBreakdown: {
                    accommodation: Math.floor(budget * 0.4),
                    food: Math.floor(budget * 0.25),
                    transportation: Math.floor(budget * 0.15),
                    activities: Math.floor(budget * 0.15),
                    miscellaneous: Math.floor(budget * 0.05)
                },
                tips: ["Plan ahead for better deals", "Try local cuisine", "Respect local customs"]
            };
        }

        res.json({ planJson: JSON.stringify(planJson) });
    } catch (error) {
        console.error('Error generating plan:', error);
        res.status(500).json({ error: 'Failed to generate travel plan' });
    }
});

// Serve the UI5 app
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'app/index.html'));
});

// Serve static files from webapp directory
app.use('/webapp', express.static(path.join(__dirname, 'app/webapp')));

// Serve the app directory for UI5 resources
app.use('/app', express.static(path.join(__dirname, 'app')));

// Serve UI5 resources with proper MIME types
app.use('/app/webapp', express.static(path.join(__dirname, 'app/webapp'), {
    setHeaders: (res, path) => {
        if (path.endsWith('.js')) {
            res.setHeader('Content-Type', 'application/javascript');
        }
    }
}));

app.listen(PORT, () => {
    console.log(`🌏 Bharat-AI Travel Agent is running!`);
    console.log(`📱 UI: http://localhost:${PORT}/`);
    console.log(`🔗 API: http://localhost:${PORT}/service/plan/`);
    console.log(`💡 Health Check: http://localhost:${PORT}/service/plan/health`);
});
