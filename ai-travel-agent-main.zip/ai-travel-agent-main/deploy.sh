#!/bin/bash

# Deployment script for SAP BTP Cloud Foundry
echo "🚀 Starting deployment to SAP BTP Cloud Foundry..."

# Check if CF CLI is installed
if ! command -v cf &> /dev/null; then
    echo "❌ Cloud Foundry CLI is not installed. Please install it first."
    echo "Download from: https://github.com/cloudfoundry/cli/releases"
    exit 1
fi

# Check if MBT is installed
if ! command -v mbt &> /dev/null; then
    echo "❌ MBT (Multi-Target Application Build Tool) is not installed."
    echo "Install with: npm install -g mbt"
    exit 1
fi

# Check if logged in to CF
if ! cf target &> /dev/null; then
    echo "❌ Not logged in to Cloud Foundry. Please login first:"
    echo "cf login -a https://api.cf.us10-001.hana.ondemand.com"
    exit 1
fi

echo "✅ Prerequisites check passed"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Build the application
echo "🔨 Building application..."
npm run build:cf

# Deploy to Cloud Foundry
echo "🚀 Deploying to Cloud Foundry..."
cf deploy ai-travel-agent_1.0.0.mtar

# Set environment variables (you'll need to replace these with your actual keys)
echo "🔧 Setting environment variables..."
echo "⚠️  Please set your API keys manually:"
echo "cf set-env ai-travel-agent-srv GEMINI_API_KEY 'your-gemini-api-key'"
echo "cf set-env ai-travel-agent-srv PEXELS_API_KEY 'your-pexels-api-key'"
echo "cf set-env ai-travel-agent-srv OPENWEATHER_API_KEY 'your-openweather-api-key'"

# Restart application
echo "🔄 Restarting application..."
cf restart ai-travel-agent-srv

# Show application info
echo "✅ Deployment completed!"
cf apps
echo ""
echo "🌐 Your application should be available at:"
cf app ai-travel-agent-srv | grep routes

echo "🎉 Deployment successful!"
