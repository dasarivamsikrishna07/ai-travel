# 🌟 AI Travel Agent

A modern, intelligent travel planning application powered by Google's Gemini 2.5-Pro AI, built with SAP CAP and featuring a clean, responsive UI.

## ✨ Features

- **🤖 AI-Powered Planning**: Advanced Gemini 2.5-Pro with intelligent fallback system
- **🌤️ Weather-Aware**: Real-time weather integration for perfect timing
- **💰 Budget-Friendly**: Smart budget optimization with detailed breakdowns
- **📸 Professional Images**: High-quality travel photography from Pexels
- **📱 Modern UI**: Clean, responsive design with smooth animations
- **🎯 Multiple Styles**: Budget, Comfort, Adventure, and Luxury options

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ and npm 8+
- Google Gemini API key

### Installation

1. **Clone and install**
   ```bash
   git clone <repository-url>
   cd ai-travel-agent
   npm install
   ```

2. **Environment setup**
   Create `.env` file:
   ```env
   GEMINI_API_KEY=your_gemini_api_key_here
   OPENWEATHER_API_KEY=your_openweather_key (optional)
   PEXELS_API_KEY=your_pexels_key (optional)
   ```

3. **Start the application**
   ```bash
   npm start
   ```

4. **Access the app**
   Open `http://localhost:4004` in your browser

## 🔑 API Keys

### Google Gemini API (Required)
1. Visit [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Create API key
3. Add to `.env` as `GEMINI_API_KEY`

### Optional APIs
- **OpenWeatherMap**: For weather data
- **Pexels**: For travel photography

## 🏗️ Architecture

### Technology Stack
- **Backend**: SAP CAP with Node.js
- **Frontend**: SAP UI5 with modern CSS
- **AI**: Google Gemini 2.5-Pro with fallback system
- **Database**: SQLite (dev) / SAP HANA (prod)

### Project Structure
```
ai-travel-agent/
├── app/webapp/           # Modern UI5 frontend
│   ├── controller/       # Smart controllers
│   ├── view/            # Clean, responsive views
│   └── css/             # Modern CSS with variables
├── srv/                 # Optimized backend
│   ├── travel-service.cds
│   └── travel-service.js # Comprehensive AI service
└── db/models/           # Clean data models
```

## 🎯 Key Improvements

### Performance Optimizations
- **Lazy loading** for better performance
- **Optimized bundle size** with clean dependencies
- **Efficient API calls** with intelligent caching
- **Responsive images** with proper sizing

### Modern UI/UX
- **Clean, modern design** with CSS variables
- **Smooth animations** and transitions
- **Mobile-first responsive** design
- **Accessibility improvements** (WCAG compliant)
- **Loading states** and error handling

### AI Reliability
- **Multi-model fallback** system (Gemini 2.0-Flash-Exp → 1.5-Flash → 1.5-Pro)
- **Intelligent quota management**
- **Comprehensive error handling**
- **120-second timeout** for complex responses

## 📱 Usage

1. **Modern Planning Interface**: Clean form with intuitive controls
2. **AI Generation**: Reliable AI with automatic fallback
3. **Rich Results**: Detailed itineraries with weather and images
4. **Responsive Experience**: Perfect on any device

## 🛠️ Development

```bash
# Development mode
npm run dev

# Build for production
npm run build

# Clean install
npm run clean
```

## 📦 Removed/Cleaned

### Files Removed
- ❌ Deployment scripts and configs
- ❌ Duplicate service files
- ❌ Unused i18n files
- ❌ Sample data files
- ❌ Cloud Foundry configs
- ❌ Unnecessary documentation

### Dependencies Optimized
- ✅ Removed HANA dependencies (dev)
- ✅ Cleaned up dev dependencies
- ✅ Optimized package.json
- ✅ Updated to latest versions

## 🎨 UI Improvements

### Visual Enhancements
- **Modern hero section** with gradient background
- **Card-based layout** with subtle shadows
- **Professional typography** with proper hierarchy
- **Consistent spacing** using CSS variables
- **Smooth hover effects** and transitions

### Responsive Design
- **Mobile-first approach**
- **Flexible grid system**
- **Optimized touch targets**
- **Readable font sizes**

## 🔧 Technical Improvements

### Code Quality
- **Clean, maintainable code**
- **Proper error handling**
- **Consistent naming conventions**
- **Optimized performance**

### Accessibility
- **WCAG 2.1 compliant**
- **Keyboard navigation**
- **Screen reader support**
- **High contrast mode**

## 📄 License

MIT License - see LICENSE file for details.

## 🙏 Acknowledgments

- Google Gemini AI for intelligent planning
- SAP for CAP framework and UI5
- OpenWeatherMap for weather data
- Pexels for professional photography
