# 🚀 SAP BTP Cloud Foundry Deployment Guide

## Prerequisites

### 1. SAP BTP Account Setup
- SAP BTP Trial Account: https://account.hanatrial.ondemand.com/
- Enable Cloud Foundry Runtime
- Enable SAP HANA Cloud service

### 2. Required Tools
```bash
# Cloud Foundry CLI
# Download from: https://github.com/cloudfoundry/cli/releases

# MTA Build Tool
npm install -g mbt

# CF MultiApps Plugin
cf install-plugin multiapps
```

### 3. API Keys Required
- **GEMINI_API_KEY**: Get from Google AI Studio
- **PEXELS_API_KEY**: Get from Pexels.com
- **OPENWEATHER_API_KEY**: Get from OpenWeatherMap.org

## Deployment Steps

### Step 1: Login to Cloud Foundry
```bash
cf login -a https://api.cf.us10-001.hana.ondemand.com
# Enter your BTP credentials
# Select your org and space
```

### Step 2: Create Services
```bash
# Create HANA HDI Container
cf create-service hana hdi-shared ai-travel-agent-db

# Create XSUAA service
cf create-service xsuaa application ai-travel-agent-uaa -c xs-security.json

# Create HTML5 App Repository
cf create-service html5-apps-repo app-host ai-travel-agent-repo-host

# Check service status
cf services
```

### Step 3: Build and Deploy
```bash
# Install dependencies
npm install

# Build for Cloud Foundry
npm run build:cf

# Deploy
cf deploy ai-travel-agent_1.0.0.mtar
```

### Step 4: Set Environment Variables
```bash
cf set-env ai-travel-agent-srv GEMINI_API_KEY "your-gemini-api-key"
cf set-env ai-travel-agent-srv PEXELS_API_KEY "your-pexels-api-key"
cf set-env ai-travel-agent-srv OPENWEATHER_API_KEY "your-openweather-api-key"

# Restart application
cf restart ai-travel-agent-srv
```

### Step 5: Verify Deployment
```bash
# Check application status
cf apps

# View logs
cf logs ai-travel-agent-srv --recent

# Test health endpoint
curl https://your-app-url.cfapps.us10-001.hana.ondemand.com/service/plan/health
```

## Quick Deploy Scripts

### Windows
```cmd
deploy.bat
```

### Linux/Mac
```bash
chmod +x deploy.sh
./deploy.sh
```

## Troubleshooting

### Common Issues
1. **Service creation timeout**: Wait and check `cf services`
2. **Build failures**: Check `npm run build` locally first
3. **Memory issues**: Scale app with `cf scale ai-travel-agent-srv -m 1G`
4. **Database connection**: Check HANA Cloud instance is running

### Useful Commands
```bash
# Scale application
cf scale ai-travel-agent-srv -i 2 -m 1G

# View environment variables
cf env ai-travel-agent-srv

# SSH into container
cf ssh ai-travel-agent-srv

# Restart application
cf restart ai-travel-agent-srv
```

## Production Considerations

### Security
- Use SAP Credential Store for API keys
- Configure proper XSUAA scopes
- Restrict HANA Cloud IP access

### Performance
- Enable application autoscaling
- Configure CDN for static assets
- Monitor with SAP Cloud ALM

### Monitoring
- Set up application logging
- Configure health checks
- Monitor database performance

## Support

For issues:
1. Check CF logs: `cf logs ai-travel-agent-srv --recent`
2. Verify services: `cf services`
3. Test locally first: `npm start`
4. Check SAP BTP Cockpit for service status
