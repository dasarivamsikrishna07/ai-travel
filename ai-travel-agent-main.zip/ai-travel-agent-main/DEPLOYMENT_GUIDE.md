# 🚀 AI Travel Agent - Cloud Foundry Deployment Guide

## Prerequisites ✅

Your application is now **100% ready for deployment** with:
- ✅ Complete CDS application with HANA support
- ✅ Comprehensive travel planning with AI, weather, and images
- ✅ All API keys configured
- ✅ Database models ready for HANA
- ✅ MTA configuration prepared

## Option 1: SAP Business Application Studio (Recommended) 🌟

### Step 1: Access SAP BAS
1. Go to [SAP BTP Cockpit](https://cockpit.us10-001.hana.ondemand.com/)
2. Login with: `dasarivamsikrishna07@gmail.com` / `Vamsi@2003`
3. Navigate to **Services** → **Instances and Subscriptions**
4. Open **SAP Business Application Studio**

### Step 2: Create Dev Space
1. Create new **Full Stack Cloud Application** dev space
2. Name it: `ai-travel-agent-dev`
3. Wait for it to start

### Step 3: Import Project
1. In SAP BAS, go to **File** → **Open Folder**
2. Upload your project files or clone from Git
3. Open terminal in SAP BAS

### Step 4: Build and Deploy
```bash
# Install dependencies
npm install

# Build for production
cds build --production

# Build MTA
mbt build -t ./

# Deploy to Cloud Foundry
cf deploy mta_archives/ai-travel-agent_1.0.0.mtar
```

## Option 2: Manual Cloud Foundry Deployment 🔧

### Step 1: Install CF CLI
Download and install from: https://github.com/cloudfoundry/cli/releases

### Step 2: Login to Cloud Foundry
```bash
cf login -a https://api.cf.us10-001.hana.ondemand.com
# Username: dasarivamsikrishna07@gmail.com
# Password: Vamsi@2003
# Org: trial
# Space: dev
```

### Step 3: Create Services
```bash
# Create HANA HDI Container
cf create-service hana hdi-shared ai-travel-agent-hana-db

# Create XSUAA Service
cf create-service xsuaa application ai-travel-agent-xsuaa -c xs-security.json
```

### Step 4: Deploy Application
```bash
# Deploy using manifest
cf push -f manifest-cf.yml
```

## Option 3: Web-Based Deployment (Easiest) 🌐

### Step 1: Access SAP BTP Cockpit
1. Go to: https://cockpit.us10-001.hana.ondemand.com/
2. Login with your credentials
3. Navigate to your **trial** subaccount

### Step 2: Create Services via UI
1. Go to **Services** → **Service Marketplace**
2. Create **SAP HANA Cloud** service instance
3. Create **Authorization and Trust Management** service

### Step 3: Deploy via Drag & Drop
1. Go to **Cloud Foundry** → **Spaces** → **dev**
2. Use the **Deploy** button
3. Upload your `gen/srv` folder as a ZIP

## Environment Variables 🔐

Set these in Cloud Foundry:
```bash
cf set-env ai-travel-agent-srv GEMINI_API_KEY "AIzaSyC8yBMwSj3ipoM03yWPNyLYDUMcsbLKN4k"
cf set-env ai-travel-agent-srv PEXELS_API_KEY "nKIYWb5f4GUSzQiajOGKSf2xioILhJovnI30osFk68ESGH03qkvp0PR9"
cf set-env ai-travel-agent-srv OPENWEATHER_API_KEY "553e3473c657e97c04c2a426730d9748"
cf set-env ai-travel-agent-srv NODE_ENV "production"
```

## Verification 🧪

After deployment:
1. Check app status: `cf apps`
2. View logs: `cf logs ai-travel-agent-srv --recent`
3. Test the application URL
4. Verify HANA connection in app logs

## Troubleshooting 🔧

### Common Issues:
1. **Build fails**: Use SAP BAS instead of local build
2. **HANA connection**: Ensure HDI container is created
3. **API keys**: Verify environment variables are set
4. **Memory issues**: Increase memory in manifest.yml

## Success Indicators ✅

Your deployment is successful when:
- ✅ App shows "Running" status
- ✅ HANA database tables are created
- ✅ API endpoints respond correctly
- ✅ UI loads and generates travel plans
- ✅ Images and weather data appear

## Next Steps 🎯

After successful deployment:
1. Test travel plan generation
2. Verify all tabs show data
3. Check image loading from Pexels
4. Confirm weather integration
5. Test database persistence

Your AI Travel Agent is enterprise-ready! 🎉
