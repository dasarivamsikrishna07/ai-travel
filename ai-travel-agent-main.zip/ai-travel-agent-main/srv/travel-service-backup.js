const cds = require('@sap/cds');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const axios = require('axios');

// Initialize database connection
let db;

async function getWeatherForBlocks(destination, date, apiKey) {
    if (!apiKey) return {};
    try {
        const geoUrl = `http://api.openweathermap.org/geo/1.0/direct?q=${encodeURIComponent(destination)}&limit=1&appid=${apiKey}`;
        const geoRes = await axios.get(geoUrl);
        if (!geoRes.data.length) return {};
        const { lat, lon } = geoRes.data[0];
        const forecastRes = await axios.get(
            `http://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`
        );
        const blocks = { Morning: 9, Afternoon: 15, Evening: 19 };
        let results = {};
        for (const [period, hour] of Object.entries(blocks)) {
            let found = forecastRes.data.list.find(fc =>
                fc.dt_txt.startsWith(date) &&
                Math.abs(parseInt(fc.dt_txt.split(' ')[1].slice(0,2)) - hour) < 2
            );
            if (found) {
                results[period] = {
                    desc: found.weather[0].description,
                    icon: found.weather[0].icon,
                    icon_url: `https://openweathermap.org/img/wn/${found.weather[0].icon}@2x.png`,
                    temp: Math.round(found.main.temp)
                };
            }
        }
        return results;
    } catch (e) {
        console.error("Weather fetch failed:", e.message);
        return {};
    }
}

function addDays(start, offset) {
    const d = new Date(start);
    d.setDate(d.getDate() + offset);
    return d.toISOString().slice(0,10);
}

async function fetchPexelsPhotos(placeName, apiKey) {
    if (!apiKey) return null;
    try {
        const response = await axios.get(`https://api.pexels.com/v1/search`, {
            headers: {
                'Authorization': apiKey
            },
            params: {
                query: placeName,
                per_page: 1,
                orientation: 'landscape'
            }
        });

        if (response.data.photos && response.data.photos.length > 0) {
            const photo = response.data.photos[0];
            return {
                url: photo.src.medium,
                photographer: photo.photographer,
                photographer_url: photo.photographer_url
            };
        }
        return null;
    } catch (error) {
        console.error(`Failed to fetch photo for ${placeName}:`, error.message);
        return null;
    }
}

module.exports = cds.service.impl(async function () {

    // Initialize database connection
    db = await cds.connect.to('db');
    console.log('🔗 Database connected successfully');

    // Health check endpoint for Cloud Foundry
    this.on('health', async (req) => {
        try {
            // Test database connection
            await db.run('SELECT 1 as test');

            return {
                status: 'healthy',
                database: 'connected',
                timestamp: new Date().toISOString()
            };
        } catch (error) {
            console.error('Health check failed:', error);
            return {
                status: 'error',
                database: 'disconnected',
                timestamp: new Date().toISOString(),
                error: error.message
            };
        }
    });

    this.on('generatePlan', async (req) => {
        console.log("🚀 Starting generatePlan function");
        try {
            const { origin, destination, startDate, endDate, budget, travelers, travelStyle } = req.data;
            console.log("📝 Request parameters:", { origin, destination, startDate, endDate, budget, travelers, travelStyle });

            if (!process.env.GEMINI_API_KEY) {
                console.error("❌ GEMINI_API_KEY is not configured");
                req.error(500, "GEMINI_API_KEY is not configured.");
                return;
            }
            if (!process.env.OPENWEATHER_API_KEY) {
                console.warn("⚠️ OPENWEATHER_API_KEY is not configured. Weather data will not be available.");
            }

            // Calculate days (exclusive end date for user selection)
            const numDays = Math.ceil((new Date(endDate) - new Date(startDate)) / (1000*60*60*24));

            const prompt = `
You are Atithi, an expert travel planner for India. Your task is to generate a detailed, personalized travel itinerary in a valid JSON format.

**User's Trip Details:**
- **Origin:** ${origin}
- **Destination:** ${destination}
- **Dates:** ${startDate} to ${endDate} (${numDays} days)
- **Budget:** ₹${budget} for ${travelers} traveler(s)
- **Travel Style:** ${travelStyle}

**JSON Output Structure:**
Please generate a single JSON object with the following structure. Do NOT include any text or markdown formatting before or after the JSON block.

CRITICAL: Use "must_visit_places" (NOT "must_try_places") in your response.

\`\`\`json
{
  "trip_summary": {
    "title": "A ${travelStyle} Trip to ${destination}",
    "destination": "${destination}",
    "duration": "${numDays} Days",
    "total_budget": ${budget},
    "best_time_to_visit": "Provide a brief note on the best season to visit."
  },
  "itinerary": [
    {
      "day": 1,
      "date": "YYYY-MM-DD",
      "theme": "e.g., Arrival & Acclimatization",
      "daily_summary": "A brief summary of the day's plan.",
      "activities": [
        {
          "time_of_day": "Morning",
          "activity": "Detailed activity name, e.g., 'Visit the Taj Mahal'",
          "location": "Specific location, e.g., 'Dharmapuri, Forest Colony, Tajganj, Agra'",
          "type": "e.g., Sightseeing, Adventure, Dining, Relaxation",
          "description": "A compelling 1-2 sentence description of the activity.",
          "cost": 0,
          "pro_tip": "A helpful tip for this activity."
        }
      ]
    }
  ],
  "recommended_accommodation_options": [
    {
      "name": "Hotel Name",
      "type": "e.g., Luxury Hotel, Budget Hostel, Boutique Guesthouse",
      "estimated_price_per_night": 0,
      "address": "Full address of the accommodation",
      "reason": "Why is this a good fit for the user's travel style and budget?"
    }
  ],
  "all_accommodation_options": [
    {
      "name": "Hotel Name",
      "type": "e.g., Luxury Hotel, Budget Hostel, Boutique Guesthouse, Heritage Hotel, Resort",
      "estimated_price_per_night": 0,
      "address": "Full address of the accommodation",
      "reason": "Why is this a good option for travelers?"
    }
  ],
  "must_try_foods": [
    {
        "name": "e.g., Masala Dosa",
        "description": "A short, enticing description of the food item.",
        "where": "e.g., Commonly found in South Indian restaurants",
        "cost": 50
    }
  ],
  "recommended_restaurants": [
    {
        "name": "Restaurant Name",
        "type": "e.g., Fine Dining, Casual, Street Food Stall",
        "city": "${destination}",
        "address": "Full address of the restaurant.",
        "recommended_for": "e.g., Authentic local cuisine, family-friendly",
        "cost": 500
    }
  ],
  "transportation_options": [
    {
      "mode": "e.g., Flight, Train, Bus, Taxi, Auto-rickshaw",
      "provider": "e.g., IndiGo, Indian Railways, RedBus, Ola, Uber",
      "route": "e.g., ${origin} to ${destination}",
      "estimated_cost": 0,
      "duration": "e.g., 2 hours, 1 day",
      "booking_url": "Direct booking website URL (e.g., https://www.makemytrip.com, https://www.irctc.co.in)",
      "description": "Brief description of this transportation option",
      "best_for": "e.g., Budget travelers, Quick travel, Scenic route"
    }
  ],
  "must_visit_places": [
    {
      "name": "e.g., Red Fort, Marina Beach, Mysore Palace",
      "type": "e.g., Historical Monument, Beach, Palace, Temple, Market",
      "description": "Detailed description of the place and why it's special",
      "location": "Full address or area name",
      "best_time_to_visit": "e.g., Early morning, Sunset, Weekdays",
      "entry_fee": 0,
      "estimated_time": "e.g., 2-3 hours, Half day",
      "tips": "Helpful tips for visiting this place"
    }
  ],
  "overall_tips": [
    "A useful tip about traveling in ${destination}."
  ],
  "expense_breakdown": {
    "accommodation": {
      "total": 0,
      "per_night": 0,
      "nights": 0
    },
    "transportation": {
      "total": 0,
      "details": "Flight/train/bus costs"
    },
    "food": {
      "total": 0,
      "per_day": 0
    },
    "activities": {
      "total": 0,
      "details": "Sightseeing, tours, entry fees"
    },
    "miscellaneous": {
      "total": 0,
      "details": "Shopping, tips, emergency fund"
    },
    "total_estimated_cost": 0
  }
}
\`\`\`

**Important Rules:**
1.  The final output must be ONLY the JSON object, enclosed in \`\`\`json ... \`\`\`.
2.  Ensure the 'itinerary' array contains exactly ${numDays} elements (not more, not less). The trip duration should be exactly ${numDays} days.
3.  Provide exactly 3 accommodation options in 'recommended_accommodation_options' and 6-8 options in 'all_accommodation_options' covering different price ranges and types. Include full addresses for all accommodations.
4.  Include at least 8-12 comprehensive travel tips in 'overall_tips' covering safety, culture, transportation, food, shopping, weather, and local customs. Each tip should start with a yellow lightbulb emoji (💡) followed by the tip text.
5.  For any list that has no relevant items, return an empty array: []. Do not invent data.
6.  Do not include a 'weather' field; it will be added by another service.
7.  Make sure all text is complete and not truncated with "..." or similar. Write full descriptions and explanations.
8.  MUST include the 'expense_breakdown' object with realistic cost estimates for accommodation, transportation, food, activities, and miscellaneous expenses. Calculate totals accurately.
9.  CRITICAL: Return ONLY valid JSON. No markdown formatting, no explanations, no text before or after the JSON.
10. Ensure all strings are properly quoted with double quotes, no trailing commas, and proper JSON syntax.
11. Do not include any comments or explanations within the JSON structure.
            `;

            const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

            // Comprehensive model fallback strategy - try until one works
            const modelOptions = [
                "gemini-1.5-flash",
                "gemini-2.0-flash-exp",
                "gemini-1.5-pro",
                "gemini-1.0-pro"
            ];

            console.log("🚀 Starting comprehensive AI model fallback system...");

            let finalResult;
            let successfulModel;
            let allErrors = [];

            let model;
            let modelName;
            let modelWorking = false;

            // Try each model until one works
            for (const testModel of modelOptions) {
                try {
                    console.log(`� Testing model: ${testModel}`);
                    model = genAI.getGenerativeModel({
                        model: testModel,
                        generationConfig: {
                            temperature: 0.7,
                            topK: 40,
                            topP: 0.95,
                            maxOutputTokens: 8192,
                        }
                    });
                    modelName = testModel;
                    modelWorking = true;
                    console.log(`✅ Using model: ${modelName}`);
                    break;
                } catch (error) {
                    console.log(`❌ Model ${testModel} failed: ${error.message}`);
                    continue;
                }
            }

            if (!modelWorking) {
                throw new Error("No Gemini models are available. Please check your API key and quota.");
            }

            // Now try the selected model with API call
            let result;
            try {
                console.log(`🤖 Calling ${modelName} API...`);

                const timeoutPromise = new Promise((_, reject) => {
                    setTimeout(() => reject(new Error(`${modelName} API timeout after 120 seconds`)), 120000);
                });

                const apiPromise = model.generateContent(prompt);
                result = await Promise.race([apiPromise, timeoutPromise]);

            } catch (error) {
                console.error(`❌ ${modelName} failed:`, error.message);
                throw new Error(`${modelName} API failed: ${error.message}`);
            }

            const response = await result.response;
            const text = response.text();
            console.log(`✅ ${modelName} API response received, length:`, text.length);
            let jsonString = text;

            // Extract JSON from markdown-wrapped block or plain
            const jsonStartIndex = text.indexOf('```json');
            if (jsonStartIndex !== -1) {
                const jsonEndIndex = text.lastIndexOf('```');
                if (jsonEndIndex > jsonStartIndex) {
                    jsonString = text.substring(jsonStartIndex + 7, jsonEndIndex).trim();
                }
            } else {
                const firstBrace = text.indexOf('{');
                const lastBrace = text.lastIndexOf('}');
                if (firstBrace !== -1 && lastBrace > firstBrace) {
                    jsonString = text.substring(firstBrace, lastBrace + 1);
                }
            }

            // Clean up common JSON formatting issues
            jsonString = jsonString
                .replace(/,(\s*[}\]])/g, '$1')  // Remove trailing commas
                .replace(/([{,]\s*)(\w+):/g, '$1"$2":')  // Quote unquoted keys
                .replace(/:\s*'([^']*)'/g, ': "$1"')  // Replace single quotes with double quotes
                .replace(/\n\s*\n/g, '\n')  // Remove empty lines
                .trim();

            let travelPlan;
            try {
                travelPlan = JSON.parse(jsonString);
            } catch (parseError) {
                console.error("JSON Parse Error:", parseError.message);
                console.error("JSON String length:", jsonString.length);
                console.error("Error position:", parseError.message.match(/position (\d+)/)?.[1]);

                // Log the problematic area around the error position
                const errorPos = parseInt(parseError.message.match(/position (\d+)/)?.[1] || "0");
                const start = Math.max(0, errorPos - 100);
                const end = Math.min(jsonString.length, errorPos + 100);
                console.error("JSON around error position:", jsonString.substring(start, end));

                // Try to create a fallback plan structure
                console.log("Creating fallback travel plan due to JSON parse error");
                travelPlan = {
                    trip_summary: {
                        title: `${numDays}-Day Trip to ${destination}`,
                        destination: destination,
                        duration: `${numDays} days`,
                        total_budget: budget,
                        travelers: travelers,
                        travel_style: travelStyle || "Balanced"
                    },
                    itinerary: [],
                    accommodation_options: [],
                    transportation_options: [],
                    must_visit_places: [],
                    must_try_places: [],
                    overall_tips: ["Plan ahead for better deals", "Try local cuisine", "Respect local customs"],
                    expense_breakdown: {
                        accommodation: Math.floor(budget * 0.4),
                        transportation: Math.floor(budget * 0.25),
                        food: Math.floor(budget * 0.2),
                        activities: Math.floor(budget * 0.1),
                        miscellaneous: Math.floor(budget * 0.05)
                    }
                };

                // Create basic itinerary
                for (let i = 1; i <= numDays; i++) {
                    const date = new Date(startDate);
                    date.setDate(date.getDate() + i - 1);
                    travelPlan.itinerary.push({
                        day: i,
                        date: date.toISOString().split('T')[0],
                        theme: `Day ${i} in ${destination}`,
                        daily_summary: `Explore ${destination} at your own pace`,
                        activities: [{
                            time_of_day: "Morning",
                            activity: "Explore local attractions",
                            location: destination,
                            type: "Sightseeing",
                            description: "Discover the beauty of the destination",
                            cost: Math.floor(budget / numDays / 3),
                            pro_tip: "Start early to avoid crowds"
                        }]
                    });
                }
            }

            // NORMALIZE ACTIVITIES ARRAY for each day (legacy fallback as well)
            if (Array.isArray(travelPlan.itinerary)) {
                travelPlan.itinerary.forEach(day => {
                    // Migrate morning/afternoon/evening keys if present
                    if (!day.activities && (day.morning || day.afternoon || day.evening)) {
                        day.activities = [];
                        if (day.morning)   day.activities.push(day.morning);
                        if (day.afternoon) day.activities.push(day.afternoon);
                        if (day.evening)   day.activities.push(day.evening);
                        delete day.morning; delete day.afternoon; delete day.evening;
                    }
                    if (!Array.isArray(day.activities) || !day.activities.length) {
                        day.activities = [{
                            time_of_day: "Morning",
                            activity: "Explore at leisure.",
                            location: "",
                            type: "",
                            description: "",
                            cost: 0,
                            pro_tip: ""
                        }];
                    }
                });
            }

            // Enforce EXACT numDays in the itinerary
            if (Array.isArray(travelPlan.itinerary) && travelPlan.itinerary.length > numDays) {
                travelPlan.itinerary = travelPlan.itinerary.slice(0, numDays);
            }
            if (Array.isArray(travelPlan.itinerary) && travelPlan.itinerary.length < numDays) {
                let last = travelPlan.itinerary[travelPlan.itinerary.length-1];
                while (travelPlan.itinerary.length < numDays) {
                    let dayCopy = Object.assign({}, last, {
                        day: travelPlan.itinerary.length + 1,
                        date: addDays(startDate, travelPlan.itinerary.length)
                    });
                    travelPlan.itinerary.push(dayCopy);
                }
            }

            // Weather injection with improved fallback
            for (let i = 0; i < numDays; ++i) {
                if (!travelPlan.itinerary || !travelPlan.itinerary[i]) continue;
                const day = travelPlan.itinerary[i];
                day.date = addDays(startDate, i);
                if (Array.isArray(day.activities)) {
                    const blockWeather = await getWeatherForBlocks(destination, day.date, process.env.OPENWEATHER_API_KEY);

                    // Create fallback weather data if API fails
                    const fallbackWeather = {
                        desc: "partly cloudy",
                        icon_url: "https://openweathermap.org/img/wn/02d@2x.png",
                        temp: "28"
                    };

                    for (let act of day.activities) {
                        let slotKey = act.time_of_day ? (
                            act.time_of_day.charAt(0).toUpperCase() + act.time_of_day.slice(1).toLowerCase()
                        ) : "Morning";

                        // Use weather data if available, otherwise use fallback
                        let wx = blockWeather[slotKey] || Object.values(blockWeather)[0] || fallbackWeather;
                        act.weather = wx;
                    }
                }
            }

            // Fetch photos for must_visit_places using Pexels API
            if (travelPlan.must_visit_places && Array.isArray(travelPlan.must_visit_places)) {
                for (let place of travelPlan.must_visit_places) {
                    const photo = await fetchPexelsPhotos(place.name, process.env.PEXELS_API_KEY);
                    if (photo) {
                        place.photo = photo;
                    }
                }
            }

            // Fetch photos for must_try_foods using Pexels API
            if (travelPlan.must_try_foods && Array.isArray(travelPlan.must_try_foods)) {
                for (let food of travelPlan.must_try_foods) {
                    // Use food name + destination for better search results
                    const searchQuery = `${food.name} ${destination} food`;
                    const photo = await fetchPexelsPhotos(searchQuery, process.env.PEXELS_API_KEY);
                    if (photo) {
                        food.photo = photo;
                    }
                }
            }

            // Handle backward compatibility: convert must_try_places to must_visit_places
            if (travelPlan.must_try_places && !travelPlan.must_visit_places) {
                console.log("Converting must_try_places to must_visit_places:", travelPlan.must_try_places);
                travelPlan.must_visit_places = travelPlan.must_try_places;
                // Keep both for compatibility
            }

            // Ensure we have the correct field name for new plans
            if (!travelPlan.must_visit_places && !travelPlan.must_try_places) {
                console.log("No must_visit_places or must_try_places found, adding sample data");
                travelPlan.must_visit_places = [
                    {
                        name: `${destination} Heritage Site`,
                        type: "Historical Monument",
                        description: `A must-visit historical landmark in ${destination} showcasing rich cultural heritage`,
                        location: `Central ${destination}`,
                        best_time_to_visit: "Early morning",
                        entry_fee: 50,
                        estimated_time: "2-3 hours",
                        tips: "Carry water and wear comfortable shoes"
                    }
                ];
            }

            // Add sample data if the new sections are missing (for demonstration)
            if (!travelPlan.transportation_options) {
                travelPlan.transportation_options = [
                    {
                        mode: "Flight",
                        provider: "IndiGo",
                        route: `${origin} to ${destination}`,
                        estimated_cost: 8000,
                        duration: "2 hours",
                        booking_url: "https://www.makemytrip.com",
                        description: "Quick and convenient air travel option",
                        best_for: "Time-conscious travelers"
                    },
                    {
                        mode: "Train",
                        provider: "Indian Railways",
                        route: `${origin} to ${destination}`,
                        estimated_cost: 1500,
                        duration: "12 hours",
                        booking_url: "https://www.irctc.co.in",
                        description: "Comfortable and economical train journey",
                        best_for: "Budget travelers"
                    }
                ];
            }

            if (!travelPlan.must_visit_places) {
                travelPlan.must_visit_places = [
                    {
                        name: `${destination} Heritage Site`,
                        type: "Historical Monument",
                        description: `A must-visit historical landmark in ${destination} showcasing rich cultural heritage`,
                        location: `Central ${destination}`,
                        best_time_to_visit: "Early morning",
                        entry_fee: 50,
                        estimated_time: "2-3 hours",
                        tips: "Carry water and wear comfortable shoes"
                    }
                ];
            }

            // ===== 🟢 Save to Database =====
            const db = await cds.connect.to('db');

            // Use cds.utils.uuid() or fallback to uuid package
            function generateUUID() {
                if (cds.utils && typeof cds.utils.uuid === "function") {
                    return cds.utils.uuid();
                } else {
                    // fallback for local/dev/test
                    return 'uuid-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
                }
            }

            // ✅ 1️⃣ Generate a UUID for the TravelPlan
            const planID = generateUUID();



            // ✅ Insert TravelPlan record (robust error handling)
            try {
                const { INSERT } = cds.ql;

                // Collect all image URLs from the travel plan
                const imageUrls = [];
                if (travelPlan.must_visit_places) {
                    travelPlan.must_visit_places.forEach(place => {
                        if (place.photo?.url) imageUrls.push(place.photo.url);
                    });
                }
                if (travelPlan.must_try_foods) {
                    travelPlan.must_try_foods.forEach(food => {
                        if (food.photo?.url) imageUrls.push(food.photo.url);
                    });
                }

                const travelPlanInsert = {
                    ID: planID,
                    user_ID: null, // later map logged-in user here
                    title: travelPlan.trip_summary?.title || `Trip to ${destination}`,
                    description: travelPlan.trip_summary?.destination || "",
                    destinations: travelPlan.trip_summary?.destination || destination,
                    origin: origin,
                    destination: destination,
                    startDate,
                    endDate,
                    duration: numDays,
                    budget,
                    travelers,
                    travelStyle: travelStyle || "Budget",
                    preferences: travelStyle || "",
                    geminiResponse: JSON.stringify(travelPlan),
                    planJson: JSON.stringify(travelPlan),
                    imageUrls: JSON.stringify(imageUrls),
                    totalCost: travelPlan.expense_breakdown?.total_estimated_cost || budget,
                    status: 'Active',
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString()
                };
                console.log('[DEBUG] Will insert TravelPlan:', travelPlanInsert);

                await db.run(INSERT.into('travel.india.TravelPlans').entries(travelPlanInsert));
                console.log(`✅ Travel Plan stored in DB with ID: ${planID}`);
            } catch (e) {
                console.error('❌ DB ERROR on TravelPlan insert:', e);
                if (e.details) console.error('Details:', e.details);
                if (e.code) console.error('Code:', e.code);
                // Don't fail the request, just log the error
                console.warn('Continuing without database storage...');
            }

            // ✅ 2️⃣ Insert DailyPlans & PlannedActivities if itinerary exists
            if (Array.isArray(travelPlan.itinerary)) {
                for (const day of travelPlan.itinerary) {
                    // 🔹 Generate UUID for each DailyPlan
                    const dailyID = generateUUID();

                    // 🔹 Insert DailyPlan with error handling
                    try {
                        const { INSERT } = cds.ql;
                        const dailyPlanInsert = {
                            ID: dailyID,
                            travelPlan_ID: planID,
                            day: day.day,
                            date: day.date,
                            city: day.city || destination,
                            theme: day.theme || "",
                            description: day.daily_summary || "",
                            budget: day.budget || 0
                        };
                        console.log('[DEBUG] Will insert DailyPlan:', dailyPlanInsert);

                        await db.run(INSERT.into('travel.india.DailyPlans').entries(dailyPlanInsert));
                    } catch (err) {
                        console.error('❌ DB ERROR on DailyPlan insert:', err);
                        console.warn('Continuing without DailyPlan storage...');
                    }

                    // 🔹 Insert all activities for this day
                    if (Array.isArray(day.activities)) {
                        for (const act of day.activities) {
                            try {
                                const { INSERT } = cds.ql;
                                const activityInsert = {
                                    ID: generateUUID(),
                                    dailyPlan_ID: dailyID,
                                    startTime: act.time_of_day || "",
                                    activity: act.activity || "",
                                    location: act.location || "",
                                    type: act.type || "",
                                    cost: act.cost || 0,
                                    priority: act.priority || "",
                                    tips: act.pro_tip || "",
                                    description: act.description || "",
                                    imageUrl: act.photo?.url || "",
                                    weatherInfo: JSON.stringify(act.weather || {})
                                };
                                console.log('[DEBUG] Will insert PlannedActivity:', activityInsert);

                                await db.run(INSERT.into('travel.india.PlannedActivities').entries(activityInsert));
                            } catch (err2) {
                                console.error('❌ DB ERROR on PlannedActivity insert:', err2);
                                console.warn('Continuing without PlannedActivity storage...');
                            }
                        }
                    }
                }
            }

            console.log(`✅ All data processed for Travel Plan ID: ${planID}`);

            // ===== Return to UI =====
            return { planJson: JSON.stringify(travelPlan) };


        } catch (error) {
            console.error("ERROR generating plan:", error.message, error.stack);
            req.error(500, "Failed to generate plan: " + error.message);
        }
    });

    // Function to retrieve a travel plan from HANA
    this.on('getTravelPlan', async (req) => {
        try {
            const { planId } = req.data;

            if (!planId) {
                req.error(400, "Plan ID is required");
                return;
            }

            const { SELECT } = cds.ql;
            const result = await db.run(
                SELECT.from('travel.india.TravelPlans')
                .where({ ID: planId })
            );

            if (!result || result.length === 0) {
                req.error(404, "Travel plan not found");
                return;
            }

            const travelPlan = result[0];

            // Return the stored plan JSON
            return {
                planJson: travelPlan.planJson || travelPlan.geminiResponse
            };

        } catch (error) {
            console.error("ERROR retrieving plan:", error.message, error.stack);
            req.error(500, "Failed to retrieve plan: " + error.message);
        }
    });

});
