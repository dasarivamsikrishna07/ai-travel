const cds = require('@sap/cds');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const axios = require('axios');

module.exports = cds.service.impl(async function() {
    console.log('🔗 Database connected successfully');

    this.on('generatePlan', async (req) => {
        console.log('🚀 Starting generatePlan function');
        
        try {
            const { origin, destination, startDate, endDate, budget, travelers, travelStyle } = req.data;
            
            console.log('📝 Request parameters:', {
                origin, destination, startDate, endDate, budget, travelers, travelStyle
            });

            // Create comprehensive prompt for Gemini 2.5-Pro
            const prompt = `You are an expert travel planner. Create a comprehensive travel plan in JSON format.

Trip Details:
- Origin: ${origin}
- Destination: ${destination}
- Start Date: ${startDate}
- End Date: ${endDate}
- Budget: ₹${budget}
- Travelers: ${travelers}
- Travel Style: ${travelStyle}

CRITICAL REQUIREMENTS:
1. Return ONLY valid JSON - no markdown, no explanations, no text before/after
2. Include weather information for each activity
3. Include professional images from Pexels for places and food
4. Make responses comprehensive and detailed
5. Include realistic cost estimates
6. Provide practical travel tips

JSON Structure Required:
{
  "trip_summary": {
    "title": "Trip title",
    "destination": "${destination}",
    "duration": "X Days",
    "total_budget": ${budget},
    "best_time_to_visit": "Best time description"
  },
  "itinerary": [
    {
      "day": 1,
      "date": "YYYY-MM-DD",
      "theme": "Day theme",
      "daily_summary": "Summary",
      "activities": [
        {
          "time_of_day": "Morning/Afternoon/Evening",
          "activity": "Activity name",
          "location": "Location",
          "type": "Type",
          "description": "Detailed description",
          "cost": 0,
          "pro_tip": "Professional tip",
          "duration": "Duration",
          "best_time": "Best time",
          "weather": {
            "desc": "Weather description",
            "icon": "weather_icon",
            "icon_url": "https://openweathermap.org/img/wn/icon@2x.png",
            "temp": 25
          }
        }
      ]
    }
  ],
  "must_visit_places": [
    {
      "name": "Place name",
      "type": "Type",
      "description": "Description",
      "location": "Location",
      "best_time_to_visit": "Best time",
      "entry_fee": 0,
      "estimated_time": "Duration",
      "tips": "Tips",
      "photo": {
        "url": "https://images.pexels.com/photos/ID/pexels-photo-ID.jpeg?auto=compress&cs=tinysrgb&h=350",
        "photographer": "Photographer Name",
        "photographer_url": "https://www.pexels.com/@photographer"
      }
    }
  ],
  "must_try_foods": [
    {
      "name": "Food name",
      "description": "Description",
      "where": "Where to find",
      "cost": 0,
      "photo": {
        "url": "https://images.pexels.com/photos/ID/pexels-photo-ID.jpeg?auto=compress&cs=tinysrgb&h=350",
        "photographer": "Photographer Name",
        "photographer_url": "https://www.pexels.com/@photographer"
      }
    }
  ],
  "recommended_restaurants": [
    {
      "name": "Restaurant name",
      "type": "Type",
      "city": "${destination}",
      "address": "Address",
      "recommended_for": "What it's known for",
      "cost": 0
    }
  ],
  "transportation_options": [
    {
      "mode": "Mode",
      "provider": "Provider",
      "route": "${origin} to ${destination}",
      "estimated_cost": 0,
      "duration": "Duration",
      "booking_url": "URL",
      "description": "Description",
      "best_for": "Best for what"
    }
  ],
  "recommended_accommodation_options": [
    {
      "name": "Hotel name",
      "type": "Type",
      "estimated_price_per_night": 0,
      "address": "Address",
      "reason": "Why recommended"
    }
  ],
  "travel_tips": [
    {
      "category": "Category",
      "tip": "Tip description",
      "importance": "High/Medium/Low"
    }
  ],
  "expense_breakdown": {
    "accommodation": 0,
    "transportation": 0,
    "food": 0,
    "activities": 0,
    "miscellaneous": 0,
    "total": 0
  }
}

Generate a comprehensive, realistic travel plan with all sections filled.`;

            // Comprehensive Gemini model fallback system
            const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
            
            const modelOptions = [
                "gemini-2.5-flash",
                "gemini-1.5-flash",
                "gemini-1.5-pro",
                "gemini-1.0-pro"
            ];

            console.log('🚀 Starting comprehensive AI model fallback system...');
            
            let finalResult;
            let successfulModel;
            let allErrors = [];

            // Try each model until one works
            for (const testModel of modelOptions) {
                try {
                    console.log(`🧪 Testing model: ${testModel}`);
                    const model = genAI.getGenerativeModel({
                        model: testModel,
                        generationConfig: {
                            temperature: 0.7,
                            topK: 40,
                            topP: 0.95,
                            maxOutputTokens: 8192,
                        }
                    });

                    console.log(`🤖 Calling ${testModel} API...`);

                    const timeoutPromise = new Promise((_, reject) => {
                        setTimeout(() => reject(new Error(`${testModel} timeout after 120 seconds`)), 120000);
                    });

                    const apiPromise = model.generateContent(prompt);
                    finalResult = await Promise.race([apiPromise, timeoutPromise]);
                    successfulModel = testModel;
                    
                    console.log(`✅ SUCCESS! ${testModel} API worked!`);
                    break; // Success - exit the loop

                } catch (error) {
                    allErrors.push(`${testModel}: ${error.message}`);
                    console.log(`❌ ${testModel} failed: ${error.message}`);
                    
                    if (error.message.includes('429') || error.message.includes('quota')) {
                        console.log(`⏳ ${testModel} quota exceeded, trying next model...`);
                    } else if (error.message.includes('404') || error.message.includes('not found')) {
                        console.log(`🔄 ${testModel} not available, trying next model...`);
                    } else {
                        console.log(`🔄 ${testModel} other error, trying next model...`);
                    }
                    
                    // Continue to next model
                    continue;
                }
            }

            // Check if any model worked
            if (!finalResult) {
                console.error('❌ ALL MODELS FAILED!');
                console.error('Errors:', allErrors);
                throw new Error(`All Gemini models failed. Errors: ${allErrors.join('; ')}`);
            }

            const response = await finalResult.response;
            const text = response.text();
            console.log(`✅ ${successfulModel} API response received, length:`, text.length);

            // Parse JSON response
            let jsonString = text;
            const jsonStartIndex = text.indexOf('```json');
            if (jsonStartIndex !== -1) {
                const jsonEndIndex = text.lastIndexOf('```');
                if (jsonEndIndex > jsonStartIndex) {
                    jsonString = text.substring(jsonStartIndex + 7, jsonEndIndex).trim();
                }
            } else {
                const firstBrace = text.indexOf('{');
                const lastBrace = text.lastIndexOf('}');
                if (firstBrace !== -1 && lastBrace > firstBrace) {
                    jsonString = text.substring(firstBrace, lastBrace + 1);
                }
            }

            let planData;
            try {
                planData = JSON.parse(jsonString);
                console.log('✅ JSON parsed successfully');
            } catch (parseError) {
                console.error('❌ JSON parse error:', parseError.message);
                throw new Error(`Failed to parse AI response as JSON: ${parseError.message}`);
            }

            // Add weather data to activities
            if (planData.itinerary) {
                for (const day of planData.itinerary) {
                    if (day.activities) {
                        for (const activity of day.activities) {
                            if (!activity.weather) {
                                activity.weather = {
                                    desc: "partly cloudy",
                                    icon: "02d",
                                    icon_url: "https://openweathermap.org/img/wn/02d@2x.png",
                                    temp: 25
                                };
                            }
                        }
                    }
                }
            }

            // Store in database
            const travelPlanId = this.generateUUID();
            const travelPlan = {
                ID: travelPlanId,
                user_ID: null,
                title: planData.trip_summary?.title || `Trip to ${destination}`,
                description: destination,
                destinations: destination,
                origin,
                destination,
                startDate,
                endDate,
                duration: Math.ceil((new Date(endDate) - new Date(startDate)) / (1000 * 60 * 60 * 24)),
                budget: parseInt(budget),
                travelers: parseInt(travelers),
                travelStyle,
                preferences: travelStyle,
                geminiResponse: JSON.stringify(planData),
                planJson: JSON.stringify(planData),
                imageUrls: JSON.stringify([]),
                totalCost: parseInt(budget),
                status: 'Active',
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            };

            console.log('[DEBUG] Will insert TravelPlan:', travelPlan);
            await INSERT.into('TravelPlans').entries(travelPlan);
            console.log(`✅ Travel Plan stored in DB with ID: ${travelPlanId}`);

            // Store daily plans and activities
            if (planData.itinerary) {
                for (const dayPlan of planData.itinerary) {
                    const dailyPlanId = this.generateUUID();
                    const dailyPlanData = {
                        ID: dailyPlanId,
                        travelPlan_ID: travelPlanId,
                        day: dayPlan.day,
                        date: dayPlan.date,
                        city: destination.toLowerCase(),
                        theme: dayPlan.theme || '',
                        description: dayPlan.daily_summary || '',
                        budget: 0
                    };

                    console.log('[DEBUG] Will insert DailyPlan:', dailyPlanData);
                    await INSERT.into('DailyPlans').entries(dailyPlanData);

                    if (dayPlan.activities) {
                        for (const activity of dayPlan.activities) {
                            const activityId = this.generateUUID();
                            const activityData = {
                                ID: activityId,
                                dailyPlan_ID: dailyPlanId,
                                startTime: activity.time_of_day || '',
                                activity: activity.activity || '',
                                location: activity.location || '',
                                type: activity.type || '',
                                cost: activity.cost || 0,
                                priority: '',
                                tips: activity.pro_tip || '',
                                description: activity.description || '',
                                imageUrl: '',
                                weatherInfo: JSON.stringify(activity.weather || {})
                            };

                            console.log('[DEBUG] Will insert PlannedActivity:', activityData);
                            await INSERT.into('PlannedActivities').entries(activityData);
                        }
                    }
                }
            }

            console.log(`✅ All data processed for Travel Plan ID: ${travelPlanId}`);

            return {
                success: true,
                planId: travelPlanId,
                message: `Travel plan generated successfully using ${successfulModel}!`,
                data: planData
            };

        } catch (error) {
            console.error('ERROR generating plan:', error.message, error);
            throw new Error(`Failed to generate plan: ${error.message}`);
        }
    });

    // Helper function to generate UUID
    this.generateUUID = function() {
        if (typeof cds.utils.uuid === 'function') {
            return cds.utils.uuid();
        } else {
            return 'uuid-' + Date.now() + '-' + Math.random().toString(36).substring(2, 9);
        }
    };
});
