const cds = require('@sap/cds');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const axios = require('axios');

// Initialize database connection
let db;

async function getWeatherForBlocks(destination, date, apiKey) {
    if (!apiKey) return {};
    try {
        const geoUrl = `http://api.openweathermap.org/geo/1.0/direct?q=${encodeURIComponent(destination)}&limit=1&appid=${apiKey}`;
        const geoRes = await axios.get(geoUrl);
        if (!geoRes.data.length) return {};
        const { lat, lon } = geoRes.data[0];
        const forecastRes = await axios.get(
            `http://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`
        );
        const blocks = { Morning: 9, Afternoon: 15, Evening: 19 };
        let results = {};
        for (const [period, hour] of Object.entries(blocks)) {
            let found = forecastRes.data.list.find(fc =>
                fc.dt_txt.startsWith(date) &&
                Math.abs(parseInt(fc.dt_txt.split(' ')[1].slice(0,2)) - hour) < 2
            );
            if (found) {
                results[period] = {
                    desc: found.weather[0].description,
                    icon: found.weather[0].icon,
                    icon_url: `https://openweathermap.org/img/wn/${found.weather[0].icon}@2x.png`,
                    temp: Math.round(found.main.temp)
                };
            }
        }
        return results;
    } catch (e) {
        console.error("Weather fetch failed:", e.message);
        return {};
    }
}

function addDays(start, offset) {
    const d = new Date(start);
    d.setDate(d.getDate() + offset);
    return d.toISOString().slice(0,10);
}

async function fetchPexelsPhotos(placeName, apiKey) {
    if (!apiKey) return null;
    try {
        const response = await axios.get(`https://api.pexels.com/v1/search`, {
            headers: {
                'Authorization': apiKey
            },
            params: {
                query: placeName,
                per_page: 1,
                orientation: 'landscape'
            }
        });

        if (response.data.photos && response.data.photos.length > 0) {
            const photo = response.data.photos[0];
            return {
                url: photo.src.medium,
                photographer: photo.photographer,
                photographer_url: photo.photographer_url
            };
        }
        return null;
    } catch (error) {
        console.error(`Failed to fetch photo for ${placeName}:`, error.message);
        return null;
    }
}

module.exports = cds.service.impl(async function () {

    // Initialize database connection
    db = await cds.connect.to('db');
    console.log('🔗 Database connected successfully');

    // Health check endpoint for Cloud Foundry
    this.on('health', async (req) => {
        try {
            // Test database connection
            await db.run('SELECT 1 as test');

            return {
                status: 'healthy',
                database: 'connected',
                timestamp: new Date().toISOString()
            };
        } catch (error) {
            console.error('Health check failed:', error);
            return {
                status: 'error',
                database: 'disconnected',
                timestamp: new Date().toISOString(),
                error: error.message
            };
        }
    });

    this.on('generatePlan', async (req) => {
        try {
            const { origin, destination, startDate, endDate, budget, travelers, travelStyle } = req.data;
            if (!process.env.GEMINI_API_KEY) {
                req.error(500, "GEMINI_API_KEY is not configured.");
                return;
            }
            if (!process.env.OPENWEATHER_API_KEY) {
                console.warn("OPENWEATHER_API_KEY is not configured. Weather data will not be available.");
            }

            // Calculate days (exclusive end date for user selection)
            const numDays = Math.ceil((new Date(endDate) - new Date(startDate)) / (1000*60*60*24));

            const prompt = `Create a detailed ${numDays}-day travel plan for ${destination}.

**CRITICAL:** Return ONLY valid JSON. No other text. Follow this exact structure:

\`\`\`json
{
  "trip_summary": {
    "title": "${numDays}-Day Journey to ${destination}",
    "destination": "${destination}",
    "duration": "${numDays} Days",
    "total_budget": ${budget},
    "best_time_to_visit": "Best time to visit ${destination}"
  },
  "itinerary": [
    {
      "day": 1,
      "date": "Day 1",
      "theme": "Arrival and Exploration",
      "daily_summary": "Arrive in ${destination} and start exploring",
      "activities": [
        {
          "time_of_day": "Morning",
          "activity": "Travel to ${destination}",
          "location": "${destination}",
          "type": "Travel",
          "description": "Journey from ${origin} to ${destination}",
          "cost": 2000,
          "pro_tip": "Start early for best experience"
        },
        {
          "time_of_day": "Afternoon",
          "activity": "Visit main attraction",
          "location": "${destination}",
          "type": "Sightseeing",
          "description": "Explore famous landmarks",
          "cost": 500,
          "pro_tip": "Best time for photos"
        },
        {
          "time_of_day": "Evening",
          "activity": "Local market visit",
          "location": "${destination}",
          "type": "Cultural",
          "description": "Experience local culture",
          "cost": 800,
          "pro_tip": "Try local food"
        }
      ]
    }
  ],
  "must_visit_places": [
    {
      "name": "Famous Palace in ${destination}",
      "type": "Historical Monument",
      "location": "${destination}",
      "description": "Beautiful historical palace with rich architecture and cultural significance",
      "entry_fee": 50,
      "best_time_to_visit": "Morning",
      "estimated_time": "2-3 hours",
      "tips": "Carry camera for photos"
    },
    {
      "name": "Local Temple in ${destination}",
      "type": "Religious Site",
      "location": "${destination}",
      "description": "Ancient temple with cultural significance and spiritual importance",
      "entry_fee": 0,
      "best_time_to_visit": "Evening",
      "estimated_time": "1-2 hours",
      "tips": "Dress modestly"
    },
    {
      "name": "City Market in ${destination}",
      "type": "Cultural Center",
      "location": "${destination}",
      "description": "Vibrant local market with handicrafts and local products",
      "entry_fee": 0,
      "best_time_to_visit": "Afternoon",
      "estimated_time": "2 hours",
      "tips": "Bargain for best prices"
    },
    {
      "name": "Garden in ${destination}",
      "type": "Natural Wonder",
      "location": "${destination}",
      "description": "Beautiful garden with local flora and peaceful atmosphere",
      "entry_fee": 25,
      "best_time_to_visit": "Morning",
      "estimated_time": "1 hour",
      "tips": "Best for morning walks"
    },
    {
      "name": "Museum in ${destination}",
      "type": "Cultural Center",
      "location": "${destination}",
      "description": "Local museum showcasing history and culture of ${destination}",
      "entry_fee": 30,
      "best_time_to_visit": "Afternoon",
      "estimated_time": "2-3 hours",
      "tips": "Audio guide available"
    },
    {
      "name": "Scenic Viewpoint in ${destination}",
      "type": "Natural Wonder",
      "location": "${destination}",
      "description": "Panoramic viewpoint offering stunning views of ${destination}",
      "entry_fee": 0,
      "best_time_to_visit": "Sunset",
      "estimated_time": "1-2 hours",
      "tips": "Best for photography during golden hour"
    }
  ],
  "must_try_foods": [
    {
      "name": "Local curry",
      "description": "Traditional curry dish with authentic spices and regional flavors",
      "cost": 250,
      "where": "Local restaurants and traditional eateries"
    },
    {
      "name": "Regional bread",
      "description": "Traditional bread served with curry, freshly baked",
      "cost": 100,
      "where": "Street food stalls and local bakeries"
    },
    {
      "name": "Sweet dessert",
      "description": "Local sweet dish made with milk and traditional ingredients",
      "cost": 150,
      "where": "Sweet shops and dessert parlors"
    },
    {
      "name": "Signature snack",
      "description": "Popular local snack unique to ${destination}",
      "cost": 80,
      "where": "Street vendors and local markets"
    }
  ],
  "recommended_restaurants": [
    {
      "name": "Traditional Restaurant",
      "type": "Traditional",
      "city": "${destination}",
      "address": "Main area, ${destination}",
      "recommended_for": "Authentic local cuisine",
      "cost": 800
    },
    {
      "name": "Popular Eatery",
      "type": "Multi-Cuisine",
      "city": "${destination}",
      "address": "Central ${destination}",
      "recommended_for": "Great variety of dishes",
      "cost": 600
    }
  ],
  "transportation_options": [
    {
      "mode": "Flight",
      "provider": "Airlines",
      "route": "${origin} to ${destination}",
      "estimated_cost": 4500,
      "duration": "2-3 hours",
      "description": "Fastest travel option",
      "best_for": "Quick travel"
    },
    {
      "mode": "Train",
      "provider": "Indian Railways",
      "route": "${origin} to ${destination}",
      "estimated_cost": 2200,
      "duration": "8-12 hours",
      "description": "Comfortable journey",
      "best_for": "Scenic travel"
    }
  ],
  "recommended_accommodation_options": [
    {
      "name": "Luxury Hotel ${destination}",
      "type": "Luxury Hotel",
      "address": "Main area, ${destination}",
      "estimated_price_per_night": 3500,
      "reason": "Premium location with excellent amenities and world-class service"
    },
    {
      "name": "Heritage Hotel ${destination}",
      "type": "Heritage Hotel",
      "address": "Historic quarter, ${destination}",
      "estimated_price_per_night": 2800,
      "reason": "Traditional architecture with cultural experience and authentic charm"
    },
    {
      "name": "Budget Hotel ${destination}",
      "type": "Budget Hotel",
      "address": "Central ${destination}",
      "estimated_price_per_night": 1500,
      "reason": "Good value with basic amenities and convenient location"
    },
    {
      "name": "Boutique Resort ${destination}",
      "type": "Boutique Resort",
      "address": "Scenic area, ${destination}",
      "estimated_price_per_night": 4200,
      "reason": "Unique design with personalized service and beautiful surroundings"
    }
  ],
  "all_accommodation_options": [
    {
      "name": "Premium Resort ${destination}",
      "type": "Resort",
      "estimated_price_per_night": 5000,
      "address": "Scenic area, ${destination}",
      "reason": "Luxury amenities with great location and spa facilities"
    },
    {
      "name": "Economy Lodge ${destination}",
      "type": "Lodge",
      "estimated_price_per_night": 800,
      "address": "Budget area, ${destination}",
      "reason": "Affordable accommodation with clean rooms"
    },
    {
      "name": "Business Hotel ${destination}",
      "type": "Business Hotel",
      "estimated_price_per_night": 2200,
      "address": "Business district, ${destination}",
      "reason": "Modern facilities with conference rooms and business center"
    },
    {
      "name": "Homestay ${destination}",
      "type": "Homestay",
      "estimated_price_per_night": 1200,
      "address": "Residential area, ${destination}",
      "reason": "Authentic local experience with home-cooked meals"
    },
    {
      "name": "Backpacker Hostel ${destination}",
      "type": "Hostel",
      "estimated_price_per_night": 600,
      "address": "Backpacker area, ${destination}",
      "reason": "Social atmosphere with shared facilities for budget travelers"
    },
    {
      "name": "Eco Resort ${destination}",
      "type": "Eco Resort",
      "estimated_price_per_night": 3800,
      "address": "Nature area, ${destination}",
      "reason": "Sustainable tourism with nature activities and organic food"
    }
  ],
  "overall_tips": [
    "💡 Weather tip: Check weather conditions before traveling to ${destination}",
    "💡 Transportation tip: Book tickets in advance for better prices",
    "💡 Food tip: Try local cuisine at recommended restaurants",
    "💡 Cultural tip: Respect local customs and traditions",
    "💡 Safety tip: Keep important documents safe",
    "💡 Money tip: Carry both cash and cards",
    "💡 Shopping tip: Bargain at local markets",
    "💡 Language tip: Learn basic local phrases",
    "💡 Accommodation tip: Book hotels in advance",
    "💡 Photography tip: Ask permission before taking photos of people"
  ],
  "expense_breakdown": {
    "accommodation": {
      "total": 15000,
      "per_night": 3000,
      "nights": ${numDays}
    },
    "transportation": {
      "total": 6000,
      "details": "Flight and local transport costs"
    },
    "food": {
      "total": 5000,
      "per_day": 1000
    },
    "activities": {
      "total": 3000,
      "details": "Sightseeing and entry fees"
    },
    "miscellaneous": {
      "total": 1000,
      "details": "Shopping and tips"
    },
    "total_estimated_cost": ${budget}
  }
  ]
}
      "details": "Sightseeing, tours, entry fees"
    }
}
\`\`\`

**CRITICAL INSTRUCTIONS:**
1. Return ONLY valid JSON in the exact format above
2. Create exactly ${numDays} days with Morning, Afternoon, Evening activities
3. Fill ALL sections with real data for ${destination}
4. MUST HAVE: 6 must_visit_places, 4 must_try_foods, 4 recommended_accommodation_options, 6 all_accommodation_options
5. Use specific place names, hotel names, restaurant names - NO generic content
6. Everything must be specific to ${destination} with detailed descriptions
            `;

            const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
            const model = genAI.getGenerativeModel({
                model: "gemini-2.5-pro",
                generationConfig: {
                    maxOutputTokens: 16000,
                    temperature: 0.7,
                },
            });
            const result = await model.generateContent(prompt);
            const text = result.response.text();
            console.log("🔍 RAW GEMINI RESPONSE (first 1000 chars):", text.substring(0, 1000));
            console.log("🔍 RAW GEMINI RESPONSE LENGTH:", text.length);
            let jsonString = text;

            // Extract JSON from markdown-wrapped block or plain
            const jsonStartIndex = text.indexOf('```json');
            if (jsonStartIndex !== -1) {
                const jsonEndIndex = text.lastIndexOf('```');
                if (jsonEndIndex > jsonStartIndex) {
                    jsonString = text.substring(jsonStartIndex + 7, jsonEndIndex).trim();
                }
            } else {
                const firstBrace = text.indexOf('{');
                const lastBrace = text.lastIndexOf('}');
                if (firstBrace !== -1 && lastBrace > firstBrace) {
                    jsonString = text.substring(firstBrace, lastBrace + 1);
                }
            }

            // Clean up common JSON formatting issues
            jsonString = jsonString
                .replace(/,(\s*[}\]])/g, '$1')  // Remove trailing commas
                .replace(/([{,]\s*)(\w+):/g, '$1"$2":')  // Quote unquoted keys
                .replace(/:\s*'([^']*)'/g, ': "$1"')  // Replace single quotes with double quotes
                .replace(/\n\s*\n/g, '\n')  // Remove empty lines
                .trim();

            let travelPlan;
            try {
                travelPlan = JSON.parse(jsonString);
                console.log("🔍 PARSED TRAVEL PLAN KEYS:", Object.keys(travelPlan));
                console.log("🔍 ITINERARY LENGTH:", travelPlan.itinerary?.length);
                console.log("🔍 MUST VISIT PLACES LENGTH:", travelPlan.must_visit_places?.length);
                console.log("🔍 MUST TRY FOODS LENGTH:", travelPlan.must_try_foods?.length);
                console.log("🔍 RECOMMENDED ACCOMMODATION LENGTH:", travelPlan.recommended_accommodation_options?.length);
            } catch (parseError) {
                console.error("JSON Parse Error:", parseError.message);
                console.error("JSON String length:", jsonString.length);
                console.error("Error position:", parseError.message.match(/position (\d+)/)?.[1]);

                // Log the problematic area around the error position
                const errorPos = parseInt(parseError.message.match(/position (\d+)/)?.[1] || "0");
                const start = Math.max(0, errorPos - 100);
                const end = Math.min(jsonString.length, errorPos + 100);
                console.error("JSON around error position:", jsonString.substring(start, end));

                // Try to create a fallback plan structure
                console.log("Creating fallback travel plan due to JSON parse error");
                travelPlan = {
                    trip_summary: {
                        title: `${numDays}-Day Trip to ${destination}`,
                        destination: destination,
                        duration: `${numDays} days`,
                        total_budget: budget,
                        travelers: travelers,
                        travel_style: travelStyle || "Balanced"
                    },
                    itinerary: [],
                    accommodation_options: [],
                    transportation_options: [],
                    must_visit_places: [],
                    must_try_places: [],
                    overall_tips: ["Plan ahead for better deals", "Try local cuisine", "Respect local customs"],
                    expense_breakdown: {
                        accommodation: Math.floor(budget * 0.4),
                        transportation: Math.floor(budget * 0.25),
                        food: Math.floor(budget * 0.2),
                        activities: Math.floor(budget * 0.1),
                        miscellaneous: Math.floor(budget * 0.05)
                    }
                };

                // Create basic itinerary
                for (let i = 1; i <= numDays; i++) {
                    const date = new Date(startDate);
                    date.setDate(date.getDate() + i - 1);
                    travelPlan.itinerary.push({
                        day: i,
                        date: date.toISOString().split('T')[0],
                        theme: `Day ${i} in ${destination}`,
                        daily_summary: `Explore ${destination} at your own pace`,
                        activities: [{
                            time_of_day: "Morning",
                            activity: "Explore local attractions",
                            location: destination,
                            type: "Sightseeing",
                            description: "Discover the beauty of the destination",
                            cost: Math.floor(budget / numDays / 3),
                            pro_tip: "Start early to avoid crowds"
                        }]
                    });
                }
            }

            // NORMALIZE ACTIVITIES ARRAY for each day (legacy fallback as well)
            if (Array.isArray(travelPlan.itinerary)) {
                travelPlan.itinerary.forEach(day => {
                    // Migrate morning/afternoon/evening keys if present
                    if (!day.activities && (day.morning || day.afternoon || day.evening)) {
                        day.activities = [];
                        if (day.morning)   day.activities.push(day.morning);
                        if (day.afternoon) day.activities.push(day.afternoon);
                        if (day.evening)   day.activities.push(day.evening);
                        delete day.morning; delete day.afternoon; delete day.evening;
                    }
                    if (!Array.isArray(day.activities) || !day.activities.length) {
                        day.activities = [{
                            time_of_day: "Morning",
                            activity: "Explore at leisure.",
                            location: "",
                            type: "",
                            description: "",
                            cost: 0,
                            pro_tip: ""
                        }];
                    }
                });
            }

            // Enforce EXACT numDays in the itinerary
            if (Array.isArray(travelPlan.itinerary) && travelPlan.itinerary.length > numDays) {
                travelPlan.itinerary = travelPlan.itinerary.slice(0, numDays);
            }
            if (Array.isArray(travelPlan.itinerary) && travelPlan.itinerary.length < numDays) {
                let last = travelPlan.itinerary[travelPlan.itinerary.length-1];
                while (travelPlan.itinerary.length < numDays) {
                    let dayCopy = Object.assign({}, last, {
                        day: travelPlan.itinerary.length + 1,
                        date: addDays(startDate, travelPlan.itinerary.length)
                    });
                    travelPlan.itinerary.push(dayCopy);
                }
            }

            // Weather injection with improved fallback
            for (let i = 0; i < numDays; ++i) {
                if (!travelPlan.itinerary || !travelPlan.itinerary[i]) continue;
                const day = travelPlan.itinerary[i];
                day.date = addDays(startDate, i);
                if (Array.isArray(day.activities)) {
                    const blockWeather = await getWeatherForBlocks(destination, day.date, process.env.OPENWEATHER_API_KEY);

                    // Create fallback weather data if API fails
                    const fallbackWeather = {
                        desc: "partly cloudy",
                        icon_url: "https://openweathermap.org/img/wn/02d@2x.png",
                        temp: "28"
                    };

                    for (let act of day.activities) {
                        let slotKey = act.time_of_day ? (
                            act.time_of_day.charAt(0).toUpperCase() + act.time_of_day.slice(1).toLowerCase()
                        ) : "Morning";

                        // Use weather data if available, otherwise use fallback
                        let wx = blockWeather[slotKey] || Object.values(blockWeather)[0] || fallbackWeather;
                        act.weather = wx;
                    }
                }
            }

            // Fetch photos for must_visit_places using Pexels API
            if (travelPlan.must_visit_places && Array.isArray(travelPlan.must_visit_places)) {
                for (let place of travelPlan.must_visit_places) {
                    const photo = await fetchPexelsPhotos(place.name, process.env.PEXELS_API_KEY);
                    if (photo) {
                        place.photo = photo;
                    }
                }
            }

            // Fetch photos for must_try_foods using Pexels API
            if (travelPlan.must_try_foods && Array.isArray(travelPlan.must_try_foods)) {
                for (let food of travelPlan.must_try_foods) {
                    // Use food name + destination for better search results
                    const searchQuery = `${food.name} ${destination} food`;
                    const photo = await fetchPexelsPhotos(searchQuery, process.env.PEXELS_API_KEY);
                    if (photo) {
                        food.photo = photo;
                    }
                }
            }

            // Handle backward compatibility: convert must_try_places to must_visit_places
            if (travelPlan.must_try_places && !travelPlan.must_visit_places) {
                console.log("Converting must_try_places to must_visit_places:", travelPlan.must_try_places);
                travelPlan.must_visit_places = travelPlan.must_try_places;
                // Keep both for compatibility
            }

            // Ensure we have the correct field name for new plans
            if (!travelPlan.must_visit_places && !travelPlan.must_try_places) {
                console.log("No must_visit_places or must_try_places found, adding sample data");
                travelPlan.must_visit_places = [
                    {
                        name: `${destination} Heritage Site`,
                        type: "Historical Monument",
                        description: `A must-visit historical landmark in ${destination} showcasing rich cultural heritage`,
                        location: `Central ${destination}`,
                        best_time_to_visit: "Early morning",
                        entry_fee: 50,
                        estimated_time: "2-3 hours",
                        tips: "Carry water and wear comfortable shoes"
                    }
                ];
            }

            // Add sample data if the new sections are missing (for demonstration)
            if (!travelPlan.transportation_options) {
                travelPlan.transportation_options = [
                    {
                        mode: "Flight",
                        provider: "IndiGo",
                        route: `${origin} to ${destination}`,
                        estimated_cost: 8000,
                        duration: "2 hours",
                        booking_url: "https://www.makemytrip.com",
                        description: "Quick and convenient air travel option",
                        best_for: "Time-conscious travelers"
                    },
                    {
                        mode: "Train",
                        provider: "Indian Railways",
                        route: `${origin} to ${destination}`,
                        estimated_cost: 1500,
                        duration: "12 hours",
                        booking_url: "https://www.irctc.co.in",
                        description: "Comfortable and economical train journey",
                        best_for: "Budget travelers"
                    }
                ];
            }

            if (!travelPlan.must_visit_places) {
                travelPlan.must_visit_places = [
                    {
                        name: `${destination} Heritage Site`,
                        type: "Historical Monument",
                        description: `A must-visit historical landmark in ${destination} showcasing rich cultural heritage`,
                        location: `Central ${destination}`,
                        best_time_to_visit: "Early morning",
                        entry_fee: 50,
                        estimated_time: "2-3 hours",
                        tips: "Carry water and wear comfortable shoes"
                    }
                ];
            }

            // ===== 🟢 Save to Database =====
            const db = await cds.connect.to('db');

            // Use cds.utils.uuid() or fallback to uuid package
            function generateUUID() {
                if (cds.utils && typeof cds.utils.uuid === "function") {
                    return cds.utils.uuid();
                } else {
                    // fallback for local/dev/test
                    return 'uuid-' + Date.now() + '-' + Math.random().toString(36).substring(2, 11);
                }
            }

            // ✅ 1️⃣ Generate a UUID for the TravelPlan
            const planID = generateUUID();



            // ✅ Insert TravelPlan record (robust error handling)
            try {
                const { INSERT } = cds.ql;

                // Collect all image URLs from the travel plan
                const imageUrls = [];
                if (travelPlan.must_visit_places) {
                    travelPlan.must_visit_places.forEach(place => {
                        if (place.photo?.url) imageUrls.push(place.photo.url);
                    });
                }
                if (travelPlan.must_try_foods) {
                    travelPlan.must_try_foods.forEach(food => {
                        if (food.photo?.url) imageUrls.push(food.photo.url);
                    });
                }

                const travelPlanInsert = {
                    ID: planID,
                    user_ID: null, // later map logged-in user here
                    title: travelPlan.trip_summary?.title || `Trip to ${destination}`,
                    description: travelPlan.trip_summary?.destination || "",
                    destinations: travelPlan.trip_summary?.destination || destination,
                    origin: origin,
                    destination: destination,
                    startDate,
                    endDate,
                    duration: numDays,
                    budget,
                    travelers,
                    travelStyle: travelStyle || "Budget",
                    preferences: travelStyle || "",
                    geminiResponse: JSON.stringify(travelPlan),
                    planJson: JSON.stringify(travelPlan),
                    imageUrls: JSON.stringify(imageUrls),
                    totalCost: travelPlan.expense_breakdown?.total_estimated_cost || budget,
                    status: 'Active',
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString()
                };
                console.log('[DEBUG] Will insert TravelPlan:', travelPlanInsert);

                await INSERT.into('TravelPlans').entries(travelPlanInsert);
                console.log(`✅ Travel Plan stored in DB with ID: ${planID}`);
            } catch (e) {
                console.error('❌ DB ERROR on TravelPlan insert:', e);
                if (e.details) console.error('Details:', e.details);
                if (e.code) console.error('Code:', e.code);
                // Don't fail the request, just log the error
                console.warn('Continuing without database storage...');
            }

            // ✅ 2️⃣ Insert DailyPlans & PlannedActivities if itinerary exists
            if (Array.isArray(travelPlan.itinerary)) {
                for (const day of travelPlan.itinerary) {
                    // 🔹 Generate UUID for each DailyPlan
                    const dailyID = generateUUID();

                    // 🔹 Insert DailyPlan with error handling
                    try {
                        const { INSERT } = cds.ql;
                        const dailyPlanInsert = {
                            ID: dailyID,
                            travelPlan_ID: planID,
                            day: day.day,
                            date: day.date,
                            city: day.city || destination,
                            theme: day.theme || "",
                            description: day.daily_summary || "",
                            budget: day.budget || 0
                        };
                        console.log('[DEBUG] Will insert DailyPlan:', dailyPlanInsert);

                        await db.run(INSERT.into('travel.india.DailyPlans').entries(dailyPlanInsert));
                    } catch (err) {
                        console.error('❌ DB ERROR on DailyPlan insert:', err);
                        console.warn('Continuing without DailyPlan storage...');
                    }

                    // 🔹 Insert all activities for this day
                    if (Array.isArray(day.activities)) {
                        for (const act of day.activities) {
                            try {
                                const { INSERT } = cds.ql;
                                const activityInsert = {
                                    ID: generateUUID(),
                                    dailyPlan_ID: dailyID,
                                    startTime: act.time_of_day || "",
                                    activity: act.activity || "",
                                    location: act.location || "",
                                    type: act.type || "",
                                    cost: act.cost || 0,
                                    priority: act.priority || "",
                                    tips: act.pro_tip || "",
                                    description: act.description || "",
                                    imageUrl: act.photo?.url || "",
                                    weatherInfo: JSON.stringify(act.weather || {})
                                };
                                console.log('[DEBUG] Will insert PlannedActivity:', activityInsert);

                                await db.run(INSERT.into('travel.india.PlannedActivities').entries(activityInsert));
                            } catch (err2) {
                                console.error('❌ DB ERROR on PlannedActivity insert:', err2);
                                console.warn('Continuing without PlannedActivity storage...');
                            }
                        }
                    }
                }
            }

            console.log(`✅ All data processed for Travel Plan ID: ${planID}`);

            // ===== Return to UI =====
            return { planJson: JSON.stringify(travelPlan) };


        } catch (error) {
            console.error("ERROR generating plan:", error.message, error.stack);
            req.error(500, "Failed to generate plan: " + error.message);
        }
    });

    // Function to retrieve a travel plan from HANA
    this.on('getTravelPlan', async (req) => {
        try {
            const { planId } = req.data;

            if (!planId) {
                req.error(400, "Plan ID is required");
                return;
            }

            const { SELECT } = cds.ql;
            const result = await db.run(
                SELECT.from('travel.india.TravelPlans')
                .where({ ID: planId })
            );

            if (!result || result.length === 0) {
                req.error(404, "Travel plan not found");
                return;
            }

            const travelPlan = result[0];

            // Return the stored plan JSON
            const planData = travelPlan.planJson || travelPlan.geminiResponse;
            return {
                data: typeof planData === 'string' ? JSON.parse(planData) : planData
            };

        } catch (error) {
            console.error("ERROR retrieving plan:", error.message, error.stack);
            req.error(500, "Failed to retrieve plan: " + error.message);
        }
    });

});