const { chromium } = require('playwright');

async function testTravelAgent() {
    console.log('🚀 Starting comprehensive AI Travel Agent test...');
    
    const browser = await chromium.launch({ 
        headless: false,
        slowMo: 1000 // Slow down for better visibility
    });
    
    const context = await browser.newContext({
        viewport: { width: 1280, height: 720 }
    });
    
    const page = await context.newPage();
    
    try {
        // Step 1: Navigate to the application
        console.log('📱 Step 1: Loading AI Travel Agent application...');
        await page.goto('http://localhost:4005/webapp/index.html#/', { 
            waitUntil: 'networkidle',
            timeout: 30000 
        });
        
        // Wait for the app to load
        await page.waitForSelector('.sapMPanel', { timeout: 10000 });
        console.log('✅ Application loaded successfully');
        
        // Step 2: Fill in the travel form
        console.log('📝 Step 2: Filling travel form...');
        
        // Fill origin
        await page.fill('#originInput-inner', 'Chennai');
        console.log('✅ Origin filled: Chennai');
        
        // Fill destination
        await page.fill('#destinationInput-inner', 'Manali');
        console.log('✅ Destination filled: Manali');
        
        // Fill start date
        await page.fill('#startDateInput-inner', '2025-08-09');
        console.log('✅ Start date filled: 2025-08-09');
        
        // Fill end date
        await page.fill('#endDateInput-inner', '2025-08-14');
        console.log('✅ End date filled: 2025-08-14');
        
        // Fill budget
        await page.fill('#budgetInput-inner', '30000');
        console.log('✅ Budget filled: ₹30,000');
        
        // Fill travelers
        await page.fill('#travelersInput-inner', '2');
        console.log('✅ Travelers filled: 2');
        
        // Select travel style
        await page.selectOption('#travelStyleSelect-inner', 'Comfort');
        console.log('✅ Travel style selected: Comfort');
        
        // Step 3: Submit the form
        console.log('🚀 Step 3: Generating travel plan...');
        await page.click('#generateButton');
        console.log('✅ Generate button clicked');
        
        // Wait for loading state
        await page.waitForSelector('.sapMBusyIndicator', { timeout: 5000 });
        console.log('⏳ Loading indicator appeared');
        
        // Step 4: Wait for results (with extended timeout for AI processing)
        console.log('⏳ Step 4: Waiting for AI to generate travel plan...');
        console.log('⏳ This may take up to 3 minutes for Gemini 2.5-Flash...');
        
        // Wait for results with very long timeout
        await page.waitForSelector('.travel-results', { 
            timeout: 300000 // 5 minutes timeout
        });
        console.log('✅ Results appeared!');
        
        // Step 5: Verify results content
        console.log('🔍 Step 5: Verifying travel plan content...');
        
        // Check for trip summary
        const tripSummary = await page.textContent('.trip-summary');
        if (tripSummary && tripSummary.length > 50) {
            console.log('✅ Trip summary found and has content');
        } else {
            console.log('❌ Trip summary missing or too short');
        }
        
        // Check for itinerary
        const itinerary = await page.$$('.day-plan');
        if (itinerary.length > 0) {
            console.log(`✅ Itinerary found with ${itinerary.length} days`);
        } else {
            console.log('❌ No itinerary found');
        }
        
        // Check for images
        const images = await page.$$('img[src*="pexels"]');
        if (images.length > 0) {
            console.log(`✅ Found ${images.length} professional images`);
        } else {
            console.log('❌ No professional images found');
        }
        
        // Check for weather information
        const weatherIcons = await page.$$('.weather-icon');
        if (weatherIcons.length > 0) {
            console.log(`✅ Found ${weatherIcons.length} weather icons`);
        } else {
            console.log('❌ No weather information found');
        }
        
        // Step 6: Test different tabs
        console.log('📑 Step 6: Testing result tabs...');
        
        // Test Itinerary tab
        await page.click('[data-tab="itinerary"]');
        await page.waitForTimeout(1000);
        console.log('✅ Itinerary tab tested');
        
        // Test Places tab
        await page.click('[data-tab="places"]');
        await page.waitForTimeout(1000);
        console.log('✅ Places tab tested');
        
        // Test Food tab
        await page.click('[data-tab="food"]');
        await page.waitForTimeout(1000);
        console.log('✅ Food tab tested');
        
        // Test Budget tab
        await page.click('[data-tab="budget"]');
        await page.waitForTimeout(1000);
        console.log('✅ Budget tab tested');
        
        // Step 7: Take screenshots
        console.log('📸 Step 7: Taking screenshots...');
        await page.screenshot({ 
            path: 'travel-agent-results.png', 
            fullPage: true 
        });
        console.log('✅ Screenshot saved as travel-agent-results.png');
        
        // Step 8: Test responsiveness
        console.log('📱 Step 8: Testing mobile responsiveness...');
        await page.setViewportSize({ width: 375, height: 667 });
        await page.waitForTimeout(2000);
        await page.screenshot({ 
            path: 'travel-agent-mobile.png', 
            fullPage: true 
        });
        console.log('✅ Mobile screenshot saved');
        
        console.log('🎉 ALL TESTS PASSED! AI Travel Agent is working perfectly!');
        
    } catch (error) {
        console.error('❌ Test failed:', error.message);
        
        // Take error screenshot
        await page.screenshot({ 
            path: 'travel-agent-error.png', 
            fullPage: true 
        });
        console.log('📸 Error screenshot saved');
        
        // Log page content for debugging
        const content = await page.content();
        console.log('📄 Page content length:', content.length);
        
        throw error;
    } finally {
        await browser.close();
    }
}

// Run the test
if (require.main === module) {
    testTravelAgent()
        .then(() => {
            console.log('✅ Test completed successfully');
            process.exit(0);
        })
        .catch((error) => {
            console.error('❌ Test failed:', error);
            process.exit(1);
        });
}

module.exports = { testTravelAgent };
