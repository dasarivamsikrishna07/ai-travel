#!/bin/bash

# AI Travel Agent - Cloud Foundry Deployment Script
echo "🚀 Deploying AI Travel Agent to Cloud Foundry..."

# Check if CF CLI is available
if ! command -v ./cf &> /dev/null; then
    echo "❌ Cloud Foundry CLI not found. Please install it first."
    exit 1
fi

# Login to Cloud Foundry (you'll need to provide your credentials)
echo "🔐 Please login to Cloud Foundry..."
./cf login

# Deploy the application
echo "📦 Deploying application..."
./cf push

echo "✅ Deployment complete!"
echo "🌐 Your app should be available at the URL shown above."
echo ""
echo "📋 Useful CF commands:"
echo "  ./cf apps                 - List all apps"
echo "  ./cf logs ai-travel-agent - View app logs"
echo "  ./cf restart ai-travel-agent - Restart the app"
echo "  ./cf delete ai-travel-agent - Delete the app"
