# Images Directory

This directory is for static images used in the UI5 application.

## Usage
- Place static images here that are referenced in the UI5 views
- Images should be optimized for web use
- Supported formats: PNG, JPG, SVG

## Current Status
- Directory is empty as the application uses dynamic images from Pexels API
- Static images can be added here for fallback or branding purposes 