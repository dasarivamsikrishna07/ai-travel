// Google Maps Configuration
window.MAPS_CONFIG = {
    // Replace with your actual Google Maps API key
    API_KEY: "AIzaSyCDjLDfKkq-t4dynUX2lUPH-lPcMP6PBSg",
    
    // Default map settings
    DEFAULT_CENTER: { lat: 20.5937, lng: 78.9629 }, // India center
    DEFAULT_ZOOM: 10,
    
    // Marker settings
    MARKER_ICON: {
        url: 'https://maps.google.com/mapfiles/ms/icons/red-dot.png',
        scaledSize: { width: 32, height: 32 }
    }
};
