sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageBox"
], function (Controller, MessageBox) {
    "use strict";

    return Controller.extend("travelapp.controller.Main", {

        onInit: function () {},

        onAfterRendering: function() { this._initializeForm(); },

        _initializeForm: function() {
            this.byId("budgetInput").setValue("30000");
            this.byId("travelersSelect").setSelectedKey("1");
            const oDateRange = this.byId("dateRangeInput");
            if (oDateRange) {
                const dToday = new Date();
                const dStartDate = new Date();
                dStartDate.setDate(dToday.getDate() + 6); // Start from Aug 8 (6 days from Aug 2)
                const dEndDate = new Date();
                dEndDate.setDate(dToday.getDate() + 11); // End on Aug 13 (5 days trip)
                oDateRange.setDateValue(dStartDate);
                oDateRange.setSecondDateValue(dEndDate);
                oDateRange.setMinDate(dToday);
            }
        },

        onGeneratePlan: function (oEvent) {
            const oButton = oEvent.getSource();

            // Add loading state to button
            oButton.setBusy(true);
            oButton.setText("Generating...");

            const sOrigin = this.byId("originInput").getValue().trim();
            const sDestination = this.byId("destinationInput").getValue().trim();
            const oDateRange = this.byId("dateRangeInput");
            const sBudget = this.byId("budgetInput").getValue();
            const sTravelers = this.byId("travelersSelect").getSelectedKey();
            const sTravelStyle = this.byId("styleSelector").getSelectedKey();
            const dStartDate = oDateRange.getDateValue();
            const dEndDate = oDateRange.getSecondDateValue();

            if (!sDestination || !dStartDate || !dEndDate) {
                MessageBox.error("Please provide a Destination and a complete Date Range (Start and End Date).");
                return;
            }

            oButton.setBusy(true);

            // Build query parameters
            const params = new URLSearchParams({
                origin: sOrigin || "Not specified",
                destination: sDestination,
                startDate: dStartDate.toISOString().split('T')[0],
                endDate: dEndDate.toISOString().split('T')[0],
                budget: parseInt(sBudget) || 25000,
                travelers: parseInt(sTravelers) || 2,
                travelStyle: sTravelStyle || "Budget"
            });

            console.log("🚀 Generating travel plan with parameters:", Object.fromEntries(params));

            // Use direct HTTP call to standalone server
            const url = `/service/plan/generatePlan?${params.toString()}`;

            // Make fetch call to standalone server
            fetch(url)
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                    }
                    return response.json();
                })
                .then(result => {
                    console.log("✅ Travel plan generated successfully:", result);
                    console.log("✅ Result type:", typeof result);
                    console.log("✅ Result.data exists:", !!result.data);
                    console.log("✅ Result keys:", Object.keys(result));

                    // Reset button state
                    oButton.setBusy(false);
                    oButton.setText("Plan My Trip");

                    // Handle both OData format (planJson) and direct format (data)
                    let travelPlan;
                    if (result.data) {
                        // Direct fetch format
                        travelPlan = result.data;
                    } else if (result.planJson) {
                        // OData format
                        try {
                            travelPlan = JSON.parse(result.planJson);
                        } catch (e) {
                            console.error("Failed to parse planJson:", e);
                            MessageBox.error("Failed to parse the travel plan from the server.");
                            return;
                        }
                    } else {
                        MessageBox.error("The server's response did not contain the expected travel plan data.");
                        return;
                    }

                    try {
                        const oResultsModel = this.getOwnerComponent().getModel("ResultsModel");
                        oResultsModel.setData(travelPlan);
                        this.getRouter().navTo("results");
                    } catch (e) {
                        console.error("Data processing error:", e);
                        MessageBox.error("Failed to process the travel plan from the server.");
                    }
                })
                .catch(error => {
                    // Reset button state on error
                    oButton.setBusy(false);
                    oButton.setText("Plan My Trip");
                    console.error("API call error:", error);
                    MessageBox.error("Failed to generate travel plan: " + (error.message || error));
                });
        },

        getRouter: function () { return this.getOwnerComponent().getRouter(); }
    });
});
