sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/routing/History",
    "sap/m/MessageBox"
], function (Controller, History, MessageBox) {
    "use strict";
    return Controller.extend("travelapp.controller.Results", {
        onInit: function () {
            this.getOwnerComponent().getRouter()
                .getRoute("results").attachPatternMatched(this._onPatternMatched, this);
        },
        _onPatternMatched: function () {
            const oResultsModel = this.getOwnerComponent().getModel("ResultsModel");
            const oData = oResultsModel.getData();

            // Robust: always set /itinerary for the view
            if (oData.days && !oData.itinerary) oResultsModel.setProperty("/itinerary", oData.days);
            if (oData.daily_itinerary && !oData.itinerary) oResultsModel.setProperty("/itinerary", oData.daily_itinerary);

            // Handle backward compatibility: convert must_try_places to must_visit_places
            if (oData.must_try_places && !oData.must_visit_places) {
                console.log("Converting must_try_places to must_visit_places:", oData.must_try_places);
                oResultsModel.setProperty("/must_visit_places", oData.must_try_places);
                // Don't delete the original property, just ensure both exist
            }

            // Force refresh the model
            oResultsModel.refresh(true);

            // Debug: Log the current data structure
            console.log("Current model data:", oResultsModel.getData());
            console.log("must_try_places:", oData.must_try_places);
            console.log("must_visit_places:", oData.must_visit_places);
        },
        onNavBack: function () {
            this.getRouter().navTo("main");
        },
        onExportPlan: function() {
            const oResultsModel = this.getOwnerComponent().getModel("ResultsModel");
            const oData = oResultsModel.getData();
            if (oData) {
                const sJsonString = JSON.stringify(oData, null, 2);
                const oBlob = new Blob([sJsonString], { type: 'application/json' });
                const sUrl = URL.createObjectURL(oBlob);
                const oLink = document.createElement('a');
                oLink.href = sUrl;
                oLink.download = `travel-plan-${oData.trip_summary?.destination || 'export'}.json`;
                document.body.appendChild(oLink);
                oLink.click();
                document.body.removeChild(oLink);
                URL.revokeObjectURL(sUrl);
            }
        },
        onRefreshPlan: function() {
            this.getRouter().navTo("main");
        },
        getRouter: function () {
            return this.getOwnerComponent().getRouter();
        }
    });
});
