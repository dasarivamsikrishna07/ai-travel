sap.ui.define([
    "sap/ui/core/mvc/Controller"
], function (Controller) {
    "use strict";
    return Controller.extend("travelapp.controller.Results", {
        onInit: function () {
            const oRouter = this.getOwnerComponent().getRouter();
            oRouter.getRoute("results").attachPatternMatched(this._onPatternMatched, this);
            oRouter.getRoute("resultsWithId").attachPatternMatched(this._onPatternMatched, this);
        },
        _onPatternMatched: function (oEvent) {
            const oResultsModel = this.getOwnerComponent().getModel("ResultsModel");
            const oData = oResultsModel.getData();

            // Check if we have a planId in the route parameters
            const oArgs = oEvent.getParameter("arguments");
            const sPlanId = oArgs.planId;

            if (sPlanId && sPlanId !== "current") {
                // Load plan from HANA database
                this._loadPlanFromDatabase(sPlanId);
            } else {
                // Use current data in model
                this._processCurrentData(oData, oResultsModel);
            }
        },

        _loadPlanFromDatabase: function(sPlanId) {
            const oResultsModel = this.getOwnerComponent().getModel("ResultsModel");
            const oModel = this.getView().getModel();

            // Use CDS OData service to get travel plan
            const oFunctionImport = oModel.bindContext("/getTravelPlan(...)");
            oFunctionImport.setParameter("planId", sPlanId);

            oFunctionImport.execute().then(() => {
                const oContext = oFunctionImport.getBoundContext();
                const oResult = oContext.getObject();

                if (oResult && oResult.planJson) {
                    const travelPlan = JSON.parse(oResult.planJson);
                    this._processCurrentData(travelPlan, oResultsModel);
                } else {
                    // Fall back to current data
                    this._processCurrentData(oResultsModel.getData(), oResultsModel);
                }
            }).catch(error => {
                console.error("Error loading plan from database:", error);
                // Fall back to current data
                this._processCurrentData(oResultsModel.getData(), oResultsModel);
            });
        },

        _processCurrentData: function(oData, oResultsModel) {
            // Robust: always set /itinerary for the view
            if (oData.days && !oData.itinerary) oResultsModel.setProperty("/itinerary", oData.days);
            if (oData.daily_itinerary && !oData.itinerary) oResultsModel.setProperty("/itinerary", oData.daily_itinerary);

            // Handle backward compatibility: convert must_try_places to must_visit_places
            if (oData.must_try_places && !oData.must_visit_places) {
                console.log("Converting must_try_places to must_visit_places:", oData.must_try_places);
                oResultsModel.setProperty("/must_visit_places", oData.must_try_places);
                // Don't delete the original property, just ensure both exist
            }

            // Update the model with processed data
            oResultsModel.setData(oData);
            oResultsModel.refresh(true);

            // Debug: Log the current data structure
            console.log("📊 Results model updated with data:", oData);
            console.log("🏛️ Must visit places:", oData.must_visit_places);
            console.log("🍽️ Must try foods:", oData.must_try_foods);
        },
        onNavBack: function () {
            this.getRouter().navTo("main");
        },
        onExportPlan: function() {
            const oResultsModel = this.getOwnerComponent().getModel("ResultsModel");
            const oData = oResultsModel.getData();
            if (oData) {
                const sJsonString = JSON.stringify(oData, null, 2);
                const oBlob = new Blob([sJsonString], { type: 'application/json' });
                const sUrl = URL.createObjectURL(oBlob);
                const oLink = document.createElement('a');
                oLink.href = sUrl;
                oLink.download = `travel-plan-${oData.trip_summary?.destination || 'export'}.json`;
                document.body.appendChild(oLink);
                oLink.click();
                document.body.removeChild(oLink);
                URL.revokeObjectURL(sUrl);
            }
        },
        onRefreshPlan: function() {
            this.getRouter().navTo("main");
        },



        getRouter: function () {
            return this.getOwnerComponent().getRouter();
        }
    });
});
