sap.ui.require.preload({
	"travelapp/Component.js": function(){
		// Component preload placeholder
		// This file is generated during build process
		// For development, we'll use individual file loading
		return;
	}
}, "travelapp/Component-preload");
