#!/bin/bash

# AI Travel Agent - Cloud Foundry Deployment Script
# This script builds and deploys the application to Cloud Foundry with HANA

echo "🚀 Starting AI Travel Agent deployment to Cloud Foundry..."

# Set variables
APP_NAME="ai-travel-agent"
CF_API="https://api.cf.us10-001.hana.ondemand.com"
CF_ORG="trial"
CF_SPACE="dev"

# API Keys (these will be set as environment variables)
GEMINI_API_KEY="AIzaSyC8yBMwSj3ipoM03yWPNyLYDUMcsbLKN4k"
PEXELS_API_KEY="nKIYWb5f4GUSzQiajOGKSf2xioILhJovnI30osFk68ESGH03qkvp0PR9"
OPENWEATHER_API_KEY="553e3473c657e97c04c2a426730d9748"
GOOGLE_MAPS_API_KEY="AIzaSyCDjLDfKkq-t4dynUX2lUPH-lPcMP6PBSg"

echo "📦 Step 1: Building MTA archive..."
mbt build -t ./

if [ $? -ne 0 ]; then
    echo "❌ MTA build failed!"
    exit 1
fi

echo "✅ MTA build completed successfully!"

echo "🔐 Step 2: Logging into Cloud Foundry..."
echo "API Endpoint: $CF_API"
echo "Username: dasarivamsikrishna07@gmail.com"

# Login to Cloud Foundry (will prompt for password)
cf login -a $CF_API -u "dasarivamsikrishna07@gmail.com" -o "$CF_ORG" -s "$CF_SPACE"

if [ $? -ne 0 ]; then
    echo "❌ Cloud Foundry login failed!"
    exit 1
fi

echo "✅ Successfully logged into Cloud Foundry!"

echo "🚀 Step 3: Deploying MTA archive..."
cf deploy mta_archives/${APP_NAME}_1.0.0.mtar

if [ $? -ne 0 ]; then
    echo "❌ MTA deployment failed!"
    exit 1
fi

echo "✅ MTA deployment completed!"

echo "🔧 Step 4: Setting environment variables..."

# Set API keys as environment variables
cf set-env ${APP_NAME}-srv GEMINI_API_KEY "$GEMINI_API_KEY"
cf set-env ${APP_NAME}-srv PEXELS_API_KEY "$PEXELS_API_KEY"
cf set-env ${APP_NAME}-srv OPENWEATHER_API_KEY "$OPENWEATHER_API_KEY"
cf set-env ${APP_NAME}-srv GOOGLE_MAPS_API_KEY "$GOOGLE_MAPS_API_KEY"
cf set-env ${APP_NAME}-srv NODE_ENV "production"

echo "✅ Environment variables set!"

echo "🔄 Step 5: Restarting application..."
cf restart ${APP_NAME}-srv

echo "📊 Step 6: Checking application status..."
cf apps

echo "🌐 Step 7: Getting application URL..."
cf app ${APP_NAME}-srv

echo ""
echo "🎉 Deployment completed successfully!"
echo "🌍 Your AI Travel Agent is now running on Cloud Foundry with HANA!"
echo ""
echo "📱 Access your application at the URL shown above"
echo "🗄️ HANA database is automatically connected via service binding"
echo ""
echo "🔧 To check logs: cf logs ${APP_NAME}-srv --recent"
echo "📊 To check status: cf app ${APP_NAME}-srv"
echo ""
