require('dotenv').config();
const express = require('express');
const path = require('path');
const { GoogleGenerativeAI } = require('@google/generative-ai');

const app = express();
const PORT = 4006;

// Middleware
app.use(express.json());
app.use('/webapp', express.static('app/webapp'));
app.use(express.static('app/webapp'));

// CORS middleware
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    if (req.method === 'OPTIONS') {
        res.sendStatus(200);
    } else {
        next();
    }
});

// Generate UUID function
function generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        const v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

// Travel plan generation endpoint
app.get('/service/plan/generatePlan', async (req, res) => {
    try {
        console.log('🚀 Starting generatePlan function');
        const { origin, destination, startDate, endDate, budget, travelers, travelStyle } = req.query;
        
        console.log('📝 Request parameters:', {
            origin, destination, startDate, endDate, budget, travelers, travelStyle
        });

        // Validate required parameters
        if (!origin || !destination || !startDate || !endDate || !budget) {
            return res.status(400).json({
                error: 'Missing required parameters: origin, destination, startDate, endDate, budget'
            });
        }

        // Create comprehensive prompt for Gemini 2.5-Flash
        const prompt = `Create a comprehensive travel plan for a trip from ${origin} to ${destination} from ${startDate} to ${endDate} with a budget of ₹${budget} for ${travelers || 1} travelers in ${travelStyle || 'Budget'} style.

Return ONLY a valid JSON object with this exact structure:
{
  "trip_summary": {
    "title": "Trip Title",
    "destination": "${destination}",
    "duration": "X Days",
    "total_budget": ${budget},
    "best_time_to_visit": "Best time description"
  },
  "itinerary": [
    {
      "day": 1,
      "date": "${startDate}",
      "theme": "Day theme",
      "daily_summary": "What to do this day",
      "activities": [
        {
          "time_of_day": "Morning/Afternoon/Evening",
          "activity": "Activity name",
          "location": "Location name",
          "type": "Activity type",
          "description": "Detailed description",
          "cost": 0,
          "pro_tip": "Professional tip",
          "duration": "Duration",
          "best_time": "Best time",
          "weather": {
            "desc": "Weather description",
            "icon": "01d",
            "icon_url": "https://openweathermap.org/img/wn/01d@2x.png",
            "temp": 25
          }
        }
      ]
    }
  ],
  "must_visit_places": [
    {
      "name": "Place name",
      "type": "Place type",
      "description": "Description",
      "location": "Location",
      "best_time_to_visit": "Best time",
      "entry_fee": 0,
      "estimated_time": "Time needed",
      "tips": "Tips",
      "photo": {
        "url": "https://images.pexels.com/photos/1234567/pexels-photo-1234567.jpeg?auto=compress&cs=tinysrgb&h=350",
        "photographer": "Photographer Name",
        "photographer_url": "https://www.pexels.com/@photographer"
      }
    }
  ],
  "must_try_foods": [
    {
      "name": "Food name",
      "description": "Description",
      "where": "Where to find",
      "cost": 0,
      "photo": {
        "url": "https://images.pexels.com/photos/1234567/pexels-photo-1234567.jpeg?auto=compress&cs=tinysrgb&h=350",
        "photographer": "Photographer Name",
        "photographer_url": "https://www.pexels.com/@photographer"
      }
    }
  ],
  "recommended_restaurants": [
    {
      "name": "Restaurant name",
      "type": "Restaurant type",
      "city": "${destination}",
      "address": "Address",
      "recommended_for": "What it's known for",
      "cost": 0
    }
  ],
  "transportation_options": [
    {
      "mode": "Transport mode",
      "provider": "Provider name",
      "route": "${origin} to ${destination}",
      "estimated_cost": 0,
      "duration": "Duration",
      "booking_url": "URL or N/A",
      "description": "Description",
      "best_for": "Best for what type of travelers"
    }
  ],
  "recommended_accommodation_options": [
    {
      "name": "Hotel/Hostel name",
      "type": "Type",
      "estimated_price_per_night": 0,
      "address": "Address",
      "reason": "Why recommended"
    }
  ],
  "travel_tips": [
    {
      "category": "Category",
      "tip": "Tip description",
      "importance": "High/Medium/Low"
    }
  ],
  "expense_breakdown": {
    "accommodation": 0,
    "transportation": 0,
    "food": 0,
    "activities": 0,
    "miscellaneous": 0,
    "total": ${budget}
  }
}

Generate a comprehensive, realistic travel plan with all sections filled.`;

        console.log('🚀 Starting comprehensive AI model fallback system...');
        
        // Initialize Gemini AI
        const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
        
        // Use Gemini 2.5-Flash as primary model with smart fallbacks
        const modelOptions = [
            "gemini-2.5-flash",
            "gemini-1.5-flash-8b",
            "gemini-1.5-flash-latest",
            "gemini-1.5-flash"
        ];
        
        let finalResult;
        let successfulModel;
        let allErrors = [];

        // Try each model until one works - intelligent quota management
        for (let i = 0; i < modelOptions.length; i++) {
            const testModel = modelOptions[i];
            try {
                console.log(`🧪 Testing model ${i + 1}/${modelOptions.length}: ${testModel}`);
                const model = genAI.getGenerativeModel({
                    model: testModel,
                    generationConfig: {
                        temperature: 0.7,
                        topK: 40,
                        topP: 0.95,
                        maxOutputTokens: 8192,
                    }
                });

                console.log(`🤖 Calling ${testModel} API...`);

                const timeoutPromise = new Promise((_, reject) => {
                    setTimeout(() => reject(new Error(`${testModel} timeout after 180 seconds`)), 180000);
                });

                const apiPromise = model.generateContent(prompt);
                finalResult = await Promise.race([apiPromise, timeoutPromise]);
                successfulModel = testModel;
                
                console.log(`✅ SUCCESS! ${testModel} API worked!`);
                break; // Success - exit the loop

            } catch (error) {
                allErrors.push(`${testModel}: ${error.message}`);
                console.log(`❌ ${testModel} failed: ${error.message}`);
                
                if (error.message.includes('429') || error.message.includes('quota')) {
                    console.log(`⏳ ${testModel} quota exceeded, waiting before next model...`);
                    // Wait 30 seconds before trying next model
                    if (i < modelOptions.length - 1) {
                        console.log(`⏳ Waiting 30 seconds before trying next model...`);
                        await new Promise(resolve => setTimeout(resolve, 30000));
                    }
                } else if (error.message.includes('404') || error.message.includes('not found')) {
                    console.log(`🔄 ${testModel} not available, trying next model immediately...`);
                } else {
                    console.log(`🔄 ${testModel} other error, waiting 10 seconds before next model...`);
                    if (i < modelOptions.length - 1) {
                        await new Promise(resolve => setTimeout(resolve, 10000));
                    }
                }
                
                // Continue to next model
                continue;
            }
        }

        if (!finalResult) {
            throw new Error(`All Gemini models failed. Errors: ${allErrors.join('; ')}`);
        }

        const responseText = finalResult.response.text();
        console.log(`✅ ${successfulModel} API response received, length: ${responseText.length}`);

        // Parse JSON response
        let planData;
        try {
            planData = JSON.parse(responseText);
            console.log('✅ JSON parsed successfully');
        } catch (parseError) {
            console.error('❌ JSON parsing failed:', parseError.message);
            throw new Error(`Failed to parse AI response as JSON: ${parseError.message}`);
        }

        // Generate response
        const travelPlanId = generateUUID();
        
        console.log(`✅ Travel plan generated successfully using ${successfulModel}!`);
        console.log(`✅ Plan data length: ${JSON.stringify(planData).length} characters`);

        const response = {
            success: true,
            planId: travelPlanId,
            message: `Travel plan generated successfully using ${successfulModel}!`,
            data: planData
        };

        res.json(response);

    } catch (error) {
        console.error('ERROR generating plan:', error.message, error);
        res.status(500).json({
            error: `Failed to generate plan: ${error.message}`
        });
    }
});

// Serve the main application
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'app', 'webapp', 'index.html'));
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 AI Travel Agent server running on http://localhost:${PORT}`);
    console.log(`📱 Open http://localhost:${PORT}/webapp/index.html#/ to test the application`);
});
